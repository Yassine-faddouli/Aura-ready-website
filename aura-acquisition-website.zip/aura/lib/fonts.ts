import fs from 'node:fs';
import path from 'node:path';

/**
 * HEADING NOW — mandatory heading typeface.
 * Drop licensed WOFF2 files in /public/fonts/heading-now/ using these exact names, then rebuild.
 * Each file found at build time gets an @font-face rule automatically. Until then, headings
 * fall back to Space Grotesk (declared in --font-heading in globals.css).
 */
const FILES = [
  { file: 'HeadingNow-Regular.woff2', weight: 400 },
  { file: 'HeadingNow-Medium.woff2', weight: 500 },
  { file: 'HeadingNow-Bold.woff2', weight: 700 },
  { file: 'HeadingNow-Black.woff2', weight: 900 },
];

export function headingNowCss(): { css: string; preload: string | null; installed: boolean } {
  const dir = path.join(process.cwd(), 'public', 'fonts', 'heading-now');
  const found = FILES.filter((f) => fs.existsSync(path.join(dir, f.file)));
  const css = found
    .map((f) => `@font-face{font-family:'Heading Now';src:url('/fonts/heading-now/${f.file}') format('woff2');font-weight:${f.weight};font-style:normal;font-display:swap;}`)
    .join('');
  const bold = found.find((f) => f.weight === 700) || found[0];
  return { css, preload: bold ? `/fonts/heading-now/${bold.file}` : null, installed: found.length > 0 };
}
