/**
 * Single source of truth for business details.
 * Anything marked TODO must be confirmed by Aura Acquisition before launch.
 */
export const site = {
  name: 'Aura Acquisition',
  legalForm: 'Auto-entrepreneur',
  url: 'https://auraacquisition.ma',
  lang: 'fr',
  locale: 'fr_MA',
  promise: 'We turn content & ads into qualified clients.',
  promiseFr: 'Nous transformons vos contenus et vos publicités en clients qualifiés.',
  description:
    "Aura Acquisition est une agence d'acquisition client basée à Casablanca. Nous aidons les centres de formation, écoles de langues, coachs et créateurs de formations au Maroc à générer des leads qualifiés grâce à Meta Ads, des funnels de conversion, la qualification et le suivi WhatsApp.",
  city: 'Casablanca',
  country: 'Maroc',
  countryCode: 'MA',
  /** TODO: confirm this is the business WhatsApp number before launch. */
  whatsapp: '212720810298',
  whatsappDisplay: '+212 7 20 81 02 98',
  /** TODO: add a professional address (e.g. contact@auraacquisition.ma) once the mailbox exists. */
  email: null as string | null,
  founder: { name: 'Yassine Faddouli', role: 'Fondateur' },
  /** TODO: add verified profile URLs — they are also used in Organization schema (sameAs). */
  social: { instagram: null as string | null, linkedin: null as string | null, facebook: null as string | null },
  formEndpoint: process.env.NEXT_PUBLIC_FORM_ENDPOINT || '',
  bookingUrl: process.env.NEXT_PUBLIC_BOOKING_URL || '',
  gaId: process.env.NEXT_PUBLIC_GA_ID || '',
  /** Future locales. Add a locale here only when real, reviewed translations exist. */
  locales: ['fr'] as const,
};

export const waLink = (message: string) =>
  `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(message)}`;

export const absUrl = (path: string) => new URL(path, site.url).toString();

export const nav = [
  { href: '/services/', label: 'Services' },
  { href: '/industries/', label: 'Secteurs' },
  { href: '/results/', label: 'Résultats' },
  { href: '/insights/', label: 'Ressources' },
  { href: '/about/', label: 'À propos' },
  { href: '/contact/', label: 'Contact' },
];

export const cta = {
  primary: { href: '/work-with-us/', label: 'Réserver un appel stratégique' },
  secondary: { href: '/services/', label: 'Découvrir nos services' },
};
