import type { Metadata } from 'next';
import { site, absUrl } from './site';

type MetaInput = { title: string; description: string; path: string; noindex?: boolean; type?: 'website' | 'article'; absoluteTitle?: boolean };

export function pageMeta({ title, description, path, noindex, type = 'website', absoluteTitle }: MetaInput): Metadata {
  return {
    title: absoluteTitle ? { absolute: title } : title,
    description,
    alternates: { canonical: path },
    openGraph: {
      title, description, url: path, siteName: site.name, locale: site.locale, type,
      images: [{ url: '/og.png', width: 1200, height: 630, alt: `${site.name} — ${site.promiseFr}` }],
    },
    twitter: { card: 'summary_large_image', title, description, images: ['/og.png'] },
    robots: noindex ? { index: false, follow: true } : undefined,
  };
}

export const orgId = `${site.url}/#organization`;
export const websiteId = `${site.url}/#website`;
export const founderId = `${site.url}/about/#founder`;

export function organizationSchema() {
  const sameAs = Object.values(site.social).filter(Boolean);
  return {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'Organization', '@id': orgId, name: site.name, url: site.url,
        logo: absUrl('/brand/logo-512.png'), description: site.description, slogan: site.promise,
        founder: { '@id': founderId },
        address: { '@type': 'PostalAddress', addressLocality: site.city, addressCountry: site.countryCode },
        areaServed: { '@type': 'Country', name: 'Maroc' },
        knowsAbout: ['Génération de leads', 'Meta Ads', 'Funnels de conversion', 'Qualification de leads', 'Automatisation WhatsApp', 'CRM'],
        contactPoint: [{ '@type': 'ContactPoint', contactType: 'sales', telephone: `+${site.whatsapp}`, availableLanguage: ['fr', 'ar', 'en'] }],
        ...(sameAs.length ? { sameAs } : {}),
      },
      { '@type': 'Person', '@id': founderId, name: site.founder.name, jobTitle: site.founder.role, worksFor: { '@id': orgId } },
      { '@type': 'WebSite', '@id': websiteId, url: site.url, name: site.name, inLanguage: 'fr-MA', publisher: { '@id': orgId } },
    ],
  };
}

export function breadcrumbSchema(items: { name: string; path: string }[]) {
  return {
    '@context': 'https://schema.org', '@type': 'BreadcrumbList',
    itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.name, item: absUrl(it.path) })),
  };
}

export function serviceSchema(s: { name: string; description: string; path: string; serviceType: string }) {
  return {
    '@context': 'https://schema.org', '@type': 'Service', name: s.name, description: s.description,
    serviceType: s.serviceType, url: absUrl(s.path), provider: { '@id': orgId },
    areaServed: { '@type': 'Country', name: 'Maroc' },
  };
}
