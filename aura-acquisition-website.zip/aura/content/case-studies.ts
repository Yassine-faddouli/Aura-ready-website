/**
 * Case studies. NOTHING here is published (indexed or linked) unless `status: 'published'`
 * AND every metric has been verified with the client (source document + written permission).
 *
 * Draft notes from the founder (to verify before publishing — do NOT publish as-is):
 *  - "25 inscriptions en 30 jours" — training center, client name/period/budget to confirm
 *  - "40 inscriptions en 30 jours" — training center, client name/period/budget to confirm
 */
export type CaseStudy = {
  slug: string;
  status: 'draft' | 'published';
  client: string;
  industry: string;
  period: string;
  summary: string;
  starting: string;
  challenge: string;
  strategy: string[];
  implementation: string[];
  metrics: { label: string; value: string; source: string }[];
  results: string;
  lessons: string[];
};

export const caseStudies: CaseStudy[] = [
  {
    slug: 'modele-etude-de-cas',
    status: 'draft',
    client: '[NOM DU CLIENT — avec autorisation écrite]',
    industry: '[Secteur]',
    period: '[Période exacte, ex. 1er sept. – 30 sept. 2026]',
    summary: '[Résumé en une phrase : qui, quoi, résultat vérifié.]',
    starting: '[Situation de départ : canaux utilisés, volume de leads, process de suivi, objectifs.]',
    challenge: '[Le problème business à résoudre.]',
    strategy: ['[Offre et angle]', '[Créas]', '[Ciblage et destination]', '[Qualification]'],
    implementation: ['[Étape 1]', '[Étape 2]', '[Étape 3]'],
    metrics: [
      { label: 'Inscriptions', value: '[À VÉRIFIER]', source: '[Document source : CRM, export Meta, registre d’inscriptions]' },
      { label: 'Budget publicitaire', value: '[À VÉRIFIER]', source: '[Export Meta Ads]' },
      { label: 'Coût par lead qualifié', value: '[À VÉRIFIER]', source: '[Calcul]' },
    ],
    results: '[Résultats et période, formulés sans exagération.]',
    lessons: ['[Leçon 1]', '[Leçon 2]'],
  },
];

export const publishedCaseStudies = caseStudies.filter((c) => c.status === 'published');
