import type { Faq } from './services';

/** Inline syntax supported in strings: [label](/path/) and **bold** */
export type Block =
  | { p: string }
  | { h3: string }
  | { ul: string[] }
  | { ol: string[] }
  | { note: string }
  | { table: { head: string[]; rows: string[][] } };

export type Article = {
  slug: string;
  title: string;
  metaTitle: string;
  description: string;
  category: string;
  published: string; // ISO date
  updated: string;
  readingMinutes: number;
  intro: string[];
  sections: { id: string; title: string; blocks: Block[] }[];
  faqs?: Faq[];
  related: string[];
  services: string[];
};

export const articles: Article[] = [
  {
    slug: 'lead-vs-lead-qualifie',
    title: 'Lead ou lead qualifié : la différence qui change votre rentabilité',
    metaTitle: 'Lead vs lead qualifié : définition, critères et exemples',
    description:
      "Quelle est la différence entre un lead et un lead qualifié ? Définition, critères concrets, exemples pour centres de formation, écoles de langues et coachs, et comment mesurer la qualité.",
    category: 'Qualification',
    published: '2026-10-29',
    updated: '2026-10-29',
    readingMinutes: 7,
    intro: [
      "« La campagne a généré 300 leads, mais on n'a presque rien vendu. » C'est l'une des phrases que l'on entend le plus souvent chez les entreprises qui investissent dans la publicité en ligne au Maroc. Le problème n'est généralement pas le volume. C'est que tous ces contacts n'étaient pas des opportunités.",
      'Comprendre la différence entre un lead et un lead qualifié permet de mieux juger vos campagnes, de mieux organiser votre équipe commerciale et, au final, de dépenser votre budget là où il produit des clients.',
    ],
    sections: [
      {
        id: 'definitions',
        title: 'Définitions simples',
        blocks: [
          { p: "Un **lead** est une personne qui a manifesté un intérêt et laissé un moyen de la contacter : un formulaire rempli, un message WhatsApp, un appel. C'est un point de départ, rien de plus." },
          { p: "Un **lead qualifié** est un lead qui correspond à des critères définis à l'avance : il fait partie de votre cible, il a un besoin réel que votre offre résout, il a un délai raisonnable et il a la capacité d'investir. C'est quelqu'un avec qui une vente est réellement possible." },
          { note: "Un lead répond à la question « qui s'est manifesté ? ». Un lead qualifié répond à la question « avec qui une vente est-elle réaliste ? »." },
        ],
      },
      {
        id: 'pourquoi',
        title: 'Pourquoi la différence compte autant',
        blocks: [
          { p: "Si vous jugez une campagne uniquement sur le coût par lead, vous risquez de privilégier celle qui attire le plus de curieux. Une publicité qui promet « cours gratuits » ou qui ne mentionne ni le prix ni le format générera beaucoup de contacts bon marché… et très peu d'inscriptions." },
          { p: 'Les conséquences sont concrètes :' },
          { ul: [
            "Votre équipe passe ses journées à rappeler des personnes qui ne répondent pas ou qui n'ont pas le budget.",
            'Les bons prospects attendent, perdent patience et s’inscrivent ailleurs.',
            "Vous augmentez le budget pour « avoir plus de leads », alors que le problème est ailleurs.",
            "Vous concluez que « Facebook ne marche pas » alors que c'est la qualification qui manque.",
          ] },
        ],
      },
      {
        id: 'criteres',
        title: 'Les critères d’un lead qualifié',
        blocks: [
          { p: 'Les critères exacts dépendent de votre activité, mais on retrouve presque toujours les mêmes familles :' },
          { table: {
            head: ['Critère', 'Question à se poser', 'Exemple'],
            rows: [
              ['Profil', 'Fait-il partie de ma cible ?', 'Parent d’un enfant de 8 à 14 ans pour un cours de langue enfant'],
              ['Besoin', 'A-t-il un problème que mon offre résout ?', 'Doit obtenir un niveau B2 pour un dossier d’études'],
              ['Zone', 'Peut-il venir, ou l’offre est-elle accessible à distance ?', 'Habite à moins de 30 minutes du centre'],
              ['Délai', 'Veut-il commencer bientôt ?', 'Souhaite démarrer avant la prochaine session'],
              ['Capacité', 'Peut-il investir dans la gamme de prix ?', 'Budget compatible, ou financement par l’employeur'],
            ],
          } },
          { p: "L'important est d'écrire ces critères noir sur blanc, de les partager avec l'équipe et de les intégrer dans le formulaire, la conversation WhatsApp et le script d'appel. Sans définition écrite, chacun juge « au feeling »." },
        ],
      },
      {
        id: 'exemples',
        title: 'Exemples par secteur',
        blocks: [
          { h3: 'Centre de formation' },
          { p: "Un lead : « Bonjour, c'est combien ? ». Un lead qualifié : une personne qui cherche une formation précise, habite dans la zone, est disponible en cours du soir et veut démarrer à la prochaine session." },
          { h3: 'École de langues' },
          { p: "Un lead : un étudiant qui « aimerait apprendre l'anglais un jour ». Un lead qualifié : un professionnel qui doit être opérationnel en anglais dans trois mois pour un nouveau poste et dont l'employeur peut financer les cours." },
          { h3: 'Coach ou consultant' },
          { p: "Un lead : quelqu'un qui a téléchargé un guide gratuit. Un lead qualifié : un dirigeant qui a décrit un problème précis, a déjà essayé de le résoudre seul et a indiqué pouvoir investir dans un accompagnement." },
        ],
      },
      {
        id: 'qualifier',
        title: 'Comment qualifier sans faire fuir les prospects',
        blocks: [
          { ol: [
            "**Ajoutez deux ou trois questions utiles au formulaire**, pas dix. Zone, objectif et délai suffisent souvent.",
            "**Donnez de l'information qui filtre dans la publicité** : format, public visé, éventuellement un prix « à partir de ».",
            "**Qualifiez dès le premier message WhatsApp** avec des questions courtes avant d’envoyer un tarif.",
            "**Attribuez un statut à chaque lead** : chaud, à nourrir, hors cible. Rappelez les chauds en premier.",
            "**Faites remonter l'information vers les campagnes** pour optimiser sur la qualité, pas seulement sur le volume.",
          ] },
          { p: 'Ajouter des questions fait généralement baisser un peu le nombre de leads. C’est le but : moins de bruit, plus de rendez-vous utiles.' },
        ],
      },
      {
        id: 'mesurer',
        title: 'Les indicateurs à suivre',
        blocks: [
          { p: 'Pour piloter la qualité, suivez chaque semaine :' },
          { ul: [
            'Le nombre de leads et le **pourcentage de leads qualifiés**',
            'Le **coût par lead qualifié** (budget ÷ leads qualifiés)',
            'Le taux de rendez-vous obtenus et le taux de présence',
            'Le taux de conversion rendez-vous → client',
            'Le **coût par client** (budget ÷ nouveaux clients)',
          ] },
          { p: "Ce sont ces chiffres, et non le coût par lead seul, qui disent si votre acquisition est rentable. Pour aller plus loin, voyez comment nous mettons en place la [qualification des leads](/services/lead-qualification/) et le [suivi CRM et WhatsApp](/services/crm-whatsapp-automation/)." },
        ],
      },
    ],
    faqs: [
      { q: 'Un lead qualifié est-il forcément prêt à acheter ?', a: "Non. Il remplit vos critères, ce qui rend une vente possible. Il peut encore avoir besoin d'informations, d'une visite ou de temps pour décider. C'est le rôle du suivi." },
      { q: 'Quel pourcentage de leads qualifiés est normal ?', a: "Il n'y a pas de chiffre universel : cela dépend de l'offre, du prix, du canal et de la manière dont la qualification est définie. L'important est de mesurer votre propre pourcentage et de l'améliorer d'une semaine à l'autre." },
    ],
    related: ['relance-prospects-centre-de-formation', 'budget-meta-ads-maroc'],
    services: ['lead-qualification', 'lead-generation'],
  },
  {
    slug: 'relance-prospects-centre-de-formation',
    title: 'Comment un centre de formation doit relancer ses prospects',
    metaTitle: 'Relance des prospects pour centre de formation : méthode',
    description:
      "Méthode concrète pour relancer les prospects d'un centre de formation ou d'une école de langues au Maroc : délais, messages WhatsApp, appels, statuts et erreurs à éviter.",
    category: 'Suivi & conversion',
    published: '2026-10-29',
    updated: '2026-10-29',
    readingMinutes: 8,
    intro: [
      "La plupart des centres de formation perdent des inscriptions non pas parce que leurs publicités sont mauvaises, mais parce que les demandes ne sont pas suivies. Un prospect envoie un message, reçoit un tarif, ne répond plus… et personne ne le recontacte.",
      'Une relance structurée est souvent le levier le plus rentable de votre acquisition : vous avez déjà payé pour obtenir ce contact. Voici une méthode simple, applicable avec WhatsApp et un tableau de suivi.',
    ],
    sections: [
      {
        id: 'vitesse',
        title: '1. Répondre vite, puis qualifier',
        blocks: [
          { p: "Le moment où le prospect a rempli le formulaire est celui où il est le plus attentif. Plus la réponse tarde, plus il compare, oublie ou s'inscrit ailleurs. Fixez un objectif clair, par exemple une réponse dans l'heure pendant les horaires d'ouverture." },
          { p: 'Le premier message ne doit pas se limiter au prix. Il doit remercier, poser deux ou trois questions et proposer une prochaine étape.' },
          { note: "Exemple : « Bonjour Salma, merci pour votre demande concernant la formation en comptabilité. Pour vous orienter vers le bon groupe : vous visez plutôt les cours du soir ou du week-end ? Et vous souhaitez démarrer à la session de novembre ? »" },
        ],
      },
      {
        id: 'calendrier',
        title: '2. Un calendrier de relance défini à l’avance',
        blocks: [
          { p: "La relance ne doit pas dépendre de la mémoire de quelqu'un. Définissez une séquence et appliquez-la à chaque prospect qui n'a pas encore décidé :" },
          { table: {
            head: ['Moment', 'Canal', 'Contenu'],
            rows: [
              ['Jour 0', 'WhatsApp', 'Réponse, questions de qualification, proposition de visite ou de test'],
              ['Jour 1', 'Appel', 'Appel court pour comprendre le besoin et répondre aux questions'],
              ['Jour 3', 'WhatsApp (texte ou vocal)', 'Information utile : planning, programme, débouchés'],
              ['Jour 7', 'WhatsApp', 'Rappel de la date de démarrage et des places disponibles (si c’est vrai)'],
              ['Avant la session', 'Appel ou WhatsApp', 'Dernière relance, puis statut final : inscrit, reporté ou perdu'],
            ],
          } },
          { p: 'Adaptez les délais à votre cycle de vente, mais gardez le principe : chaque prospect a une prochaine action datée.' },
        ],
      },
      {
        id: 'messages',
        title: '3. Des relances qui apportent quelque chose',
        blocks: [
          { p: "« Vous êtes toujours intéressé ? » est la relance la moins efficace. Chaque message doit donner une raison de répondre :" },
          { ul: [
            'Une information concrète : planning, contenu du programme, profil du formateur',
            'Une preuve réelle : retour d’un ancien étudiant (avec son accord), photo d’une séance',
            'Une invitation : visite du centre, séance d’essai, journée portes ouvertes',
            'Une échéance réelle : date de démarrage, nombre de places dans le groupe',
          ] },
          { p: "N'inventez jamais d'urgence : un prospect qui découvre que « les dernières places » ne l'étaient pas ne vous fera plus confiance." },
        ],
      },
      {
        id: 'statuts',
        title: '4. Des statuts clairs pour chaque prospect',
        blocks: [
          { p: 'Un simple tableau partagé avec quelques colonnes suffit pour commencer :' },
          { ul: [
            'Date de la demande et source (publicité, site, appel, visite)',
            'Statut : nouveau, contacté, qualifié, visite/test prévu, inscrit, reporté, perdu',
            'Date et nature de la prochaine action',
            'Motif de perte (prix, horaires, distance, injoignable…)',
          ] },
          { p: "Le motif de perte est précieux : s'il revient toujours « horaires », le problème n'est pas la publicité mais le planning." },
        ],
      },
      {
        id: 'erreurs',
        title: '5. Les erreurs à éviter',
        blocks: [
          { ul: [
            'Envoyer une grille tarifaire sans aucune question ni prochaine étape',
            'Relancer une seule fois puis abandonner',
            'Gérer les prospects sur plusieurs téléphones personnels, sans suivi commun',
            'Envoyer des messages en masse à des personnes qui ne l’ont pas demandé',
            'Ne jamais clôturer : un prospect sans statut final pollue le pipeline',
          ] },
        ],
      },
      {
        id: 'mesurer',
        title: 'Mesurer l’effet de la relance',
        blocks: [
          { p: "Comparez chaque mois le taux d'inscription des prospects relancés selon la séquence avec ceux qui ne l'ont pas été. Suivez aussi le délai moyen de première réponse. Ces deux chiffres suffisent souvent à convaincre une équipe de l'intérêt de la méthode." },
          { p: 'Nous mettons ce type de process en place pour les [centres de formation](/industries/training-centers/) et les [centres de langues](/industries/language-centers/), avec un [pipeline CRM et des relances WhatsApp](/services/crm-whatsapp-automation/) adaptés à la taille de l’équipe.' },
        ],
      },
    ],
    faqs: [
      { q: 'Combien de fois faut-il relancer un prospect ?', a: "Il n'y a pas de nombre magique, mais une seule relance est presque toujours insuffisante. Une séquence de quatre à cinq contacts répartis sur une ou deux semaines, chacun apportant une information utile, est un bon point de départ." },
      { q: 'Les notes vocales WhatsApp sont-elles efficaces ?', a: 'Elles humanisent l’échange et sont très utilisées au Maroc. Gardez-les courtes, claires et terminez par une question ou une proposition précise.' },
    ],
    related: ['lead-vs-lead-qualifie', 'budget-meta-ads-maroc'],
    services: ['crm-whatsapp-automation', 'sales-conversion'],
  },
  {
    slug: 'budget-meta-ads-maroc',
    title: 'Quel budget prévoir pour générer des leads avec Meta Ads au Maroc ?',
    metaTitle: 'Budget Meta Ads Maroc : combien investir pour des leads ?',
    description:
      "Comment calculer le budget Meta Ads nécessaire pour générer des leads au Maroc : méthode à partir de votre objectif de clients, phase de test, erreurs fréquentes et indicateurs à suivre.",
    category: 'Meta Ads',
    published: '2026-10-29',
    updated: '2026-10-29',
    readingMinutes: 7,
    intro: [
      "« Combien faut-il mettre en publicité ? » est souvent la première question d'un dirigeant qui veut lancer des campagnes Facebook et Instagram. La réponse honnête est : cela dépend de votre objectif, de votre offre et de votre capacité à convertir les leads.",
      "Plutôt qu'un chiffre arbitraire, voici une méthode pour estimer un budget cohérent, le tester sans prendre de risque excessif et savoir quand l'augmenter.",
    ],
    sections: [
      {
        id: 'partir-objectif',
        title: 'Partir de l’objectif, pas du budget',
        blocks: [
          { p: "Le bon raisonnement part du nombre de clients ou d'inscriptions souhaités, puis remonte l'entonnoir :" },
          { ol: [
            'Combien de nouveaux clients voulez-vous ce mois-ci ?',
            'Sur 10 rendez-vous ou visites, combien deviennent clients chez vous aujourd’hui ?',
            'Sur 10 leads, combien acceptent un rendez-vous ou une visite ?',
            'Combien coûte un lead dans votre secteur et votre zone ? (à mesurer pendant le test)',
          ] },
          { p: 'Ces taux vous sont propres. Si vous ne les connaissez pas, la première mission de la phase de test est de les mesurer.' },
        ],
      },
      {
        id: 'exemple',
        title: 'Un exemple de calcul',
        blocks: [
          { p: "Les chiffres ci-dessous sont **purement illustratifs**, pour montrer la méthode. Ils ne représentent ni une moyenne du marché ni un résultat promis." },
          { table: {
            head: ['Étape', 'Hypothèse', 'Résultat'],
            rows: [
              ['Objectif', '10 nouvelles inscriptions', '10 clients'],
              ['Conversion RDV → client', '1 sur 4', '40 rendez-vous nécessaires'],
              ['Conversion lead → RDV', '1 sur 3', '120 leads nécessaires'],
              ['Coût par lead mesuré', 'X MAD', 'Budget ≈ 120 × X MAD'],
            ],
          } },
          { p: "Ce calcul montre aussi un point essentiel : améliorer la conversion après le lead réduit directement le budget nécessaire. Passer de 1 sur 4 à 1 sur 3 en rendez-vous change tout le calcul." },
        ],
      },
      {
        id: 'phase-test',
        title: 'La phase de test',
        blocks: [
          { p: "Avant d'investir à grande échelle, une phase de test permet de mesurer vos vrais coûts et la qualité des leads. Quelques principes :" },
          { ul: [
            'Une structure simple : une campagne, peu d’ensembles de publicités',
            'Une variable testée à la fois (par exemple trois accroches sur un même corps de vidéo)',
            "Un budget quotidien constant pendant au moins une à deux semaines pour laisser l'algorithme apprendre",
            'Un suivi de la qualité des leads dès le premier jour, pas seulement du volume',
          ] },
          { p: "Le montant exact du test dépend de votre zone, de votre offre et du nombre de leads nécessaires pour prendre une décision. Nous le fixons avec vous avant tout lancement, à partir de vos objectifs." },
        ],
      },
      {
        id: 'augmenter',
        title: 'Quand augmenter le budget',
        blocks: [
          { p: 'Augmentez progressivement quand trois conditions sont réunies :' },
          { ul: [
            'Le coût par lead qualifié est stable sur plusieurs jours',
            'Votre équipe arrive à rappeler tous les leads rapidement',
            'Les leads se transforment en rendez-vous et en clients à un coût acceptable pour votre marge',
          ] },
          { p: "Si votre équipe ne suit déjà pas le rythme, augmenter le budget revient à payer pour des leads qui ne seront jamais rappelés. Il vaut mieux d'abord renforcer le [suivi et l'automatisation](/services/crm-whatsapp-automation/)." },
        ],
      },
      {
        id: 'erreurs',
        title: 'Les erreurs qui gaspillent le budget',
        blocks: [
          { ul: [
            'Booster des publications au lieu de créer de vraies campagnes de génération de leads',
            'Changer les réglages tous les jours sans laisser le temps d’apprendre',
            'Cibler tout le Maroc pour une offre en présentiel',
            'Juger les campagnes sur le coût par lead sans regarder la qualité',
            'Ne pas compter le budget publicitaire séparément des honoraires de gestion',
          ] },
        ],
      },
      {
        id: 'resume',
        title: 'En résumé',
        blocks: [
          { p: "Le bon budget est celui qui permet d'atteindre votre objectif de clients avec un coût par client compatible avec votre marge. Il se calcule à partir de vos propres taux de conversion, se valide par un test, puis augmente progressivement. Découvrez comment nous gérons vos [campagnes Meta Ads](/services/meta-ads/) ou [réservez un appel stratégique](/work-with-us/) pour estimer votre budget ensemble." },
        ],
      },
    ],
    faqs: [
      { q: 'Le budget publicitaire inclut-il les frais d’agence ?', a: 'Non. Le budget publicitaire est payé directement à Meta. Les honoraires d’agence couvrent la stratégie, la production, la gestion et le suivi, et sont facturés séparément.' },
      { q: 'Peut-on commencer avec un petit budget ?', a: "Oui, à condition d'accepter qu'il faudra plus de temps pour obtenir assez de données et que les conclusions seront moins rapides. L'essentiel est que le budget soit cohérent avec l'objectif fixé." },
    ],
    related: ['lead-vs-lead-qualifie', 'relance-prospects-centre-de-formation'],
    services: ['meta-ads', 'lead-generation'],
  },
];

export const getArticle = (slug: string) => articles.find((a) => a.slug === slug);
