/**
 * Real creative work produced by Aura Acquisition for clients.
 * Client names are intentionally NOT shown until each client gives written permission.
 * To credit a client, add `client: 'Name'` once permission is obtained.
 */
export type WorkItem = { id: string; title: string; sector: string; format: string; client?: string };

export const work: WorkItem[] = [
  { id: 'work-05', title: 'Journée portes ouvertes', sector: 'Centre de formation', format: 'Vidéo événementielle' },
  { id: 'work-03', title: 'Campagne inscriptions — parents', sector: 'École privée', format: 'Publicité Meta' },
  { id: 'work-01', title: 'Format podcast', sector: 'Coach', format: 'Contenu de marque' },
  { id: 'work-06', title: 'Summer Camp — version française', sector: 'Centre de formation', format: 'Publicité Meta' },
  { id: 'work-02', title: 'Présentation de l’établissement', sector: 'École privée', format: 'Publicité Meta' },
  { id: 'work-11', title: 'Formation management hôtelier', sector: 'École de formation', format: 'Publicité Meta' },
  { id: 'work-09', title: 'Vidéo de présentation', sector: 'Centre de formation', format: 'Vidéo de marque' },
  { id: 'work-07', title: 'Summer Camp — version arabe', sector: 'Centre de formation', format: 'Publicité Meta' },
  { id: 'work-04', title: 'Programme 60 jours', sector: 'Centre de formation', format: 'Publicité Meta' },
  { id: 'work-10', title: 'Campagne de rentrée', sector: 'École de formation', format: 'Publicité Meta' },
  { id: 'work-08', title: 'Formation communication', sector: 'Centre de formation', format: 'Publicité Meta' },
];
