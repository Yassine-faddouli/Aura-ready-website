export type Faq = { q: string; a: string };
export type Step = { title: string; text: string };

export type Service = {
  slug: string;
  name: string;
  short: string;
  serviceType: string;
  h1: string;
  metaTitle: string;
  metaDescription: string;
  intro: string;
  problemTitle: string;
  problem: string[];
  forWho: string[];
  process: Step[];
  deliverables: string[];
  faqs: Faq[];
  related: string[];
};

export const services: Service[] = [
  {
    slug: 'lead-generation',
    name: 'Génération de leads',
    short: "Un système complet qui attire des prospects ciblés, les qualifie et les transmet à votre équipe prêts à être appelés.",
    serviceType: 'Génération de leads B2C et B2B',
    h1: 'Génération de leads qualifiés pour les entreprises au Maroc',
    metaTitle: 'Agence de génération de leads au Maroc — leads qualifiés',
    metaDescription:
      "Aura Acquisition construit votre système de génération de leads au Maroc : offre, publicités Meta, formulaire qualifiant et suivi WhatsApp. Des prospects ciblés, pas des contacts au hasard.",
    intro:
      "La génération de leads n'est pas une campagne isolée. C'est une chaîne : une offre claire, un message qui attire les bonnes personnes, un formulaire qui filtre, puis un suivi rapide. Nous construisons et pilotons cette chaîne de bout en bout pour que votre équipe passe son temps avec des prospects qui ont une vraie intention.",
    problemTitle: 'Le problème : beaucoup de contacts, peu de clients',
    problem: [
      "Vous recevez des messages « prix ? » qui ne répondent plus après la première réponse.",
      "Votre équipe appelle des numéros qui ne correspondent pas à votre cible, votre zone ou votre budget.",
      "Les résultats dépendent du bouche-à-oreille et varient fortement d'un mois à l'autre.",
      "Vous ne savez pas combien coûte réellement un client, seulement combien coûte un message.",
    ],
    forWho: [
      'Centres de formation et écoles de langues qui veulent remplir leurs sessions de façon régulière',
      'Coachs et consultants qui vendent un accompagnement à forte valeur',
      'Créateurs de formations qui veulent des inscriptions, pas seulement des abonnés',
      'Entreprises qui ont déjà une offre qui fonctionne et un minimum de capacité commerciale pour rappeler les leads',
    ],
    process: [
      { title: 'Diagnostic', text: "Nous analysons votre offre, votre prix, votre cible, vos anciens leads et la façon dont votre équipe les traite aujourd'hui." },
      { title: 'Offre et message', text: "Nous clarifions la promesse, les objections et les angles qui parlent à votre client idéal, en français, en darija ou en arabe selon la cible." },
      { title: 'Acquisition', text: 'Nous produisons les créas et lançons les campagnes Meta Ads (Facebook, Instagram) avec un budget de test maîtrisé.' },
      { title: 'Qualification', text: "Formulaire et questions de filtrage : zone, besoin, délai, capacité à investir. Chaque lead arrive avec son contexte." },
      { title: 'Suivi et optimisation', text: "Relances WhatsApp, suivi dans un tableau ou un CRM, revue hebdomadaire du coût par lead qualifié et des rendez-vous obtenus." },
    ],
    deliverables: [
      "Diagnostic d'acquisition et recommandations écrites",
      'Angles publicitaires et scripts vidéo',
      'Campagnes Meta Ads configurées et suivies',
      'Formulaire de lead avec questions de qualification',
      'Pipeline de suivi (Google Sheets ou CRM) et scripts de relance',
      'Rapport hebdomadaire : leads, leads qualifiés, rendez-vous, coût par résultat',
    ],
    faqs: [
      { q: "Qu'est-ce qu'une agence de génération de leads ?", a: "C'est une agence qui se charge d'attirer des prospects intéressés par votre offre et de vous transmettre leurs coordonnées. Chez Aura, nous ajoutons la qualification et le suivi, car un lead non rappelé ou non filtré a très peu de valeur." },
      { q: 'Garantissez-vous un nombre de clients ?', a: "Non. Le résultat dépend aussi de votre offre, de votre prix et de la rapidité de votre équipe à rappeler. Nous nous engageons sur la méthode, la transparence des chiffres et l'optimisation continue, pas sur des promesses que personne ne peut tenir honnêtement." },
      { q: 'En combien de temps voit-on les premiers leads ?', a: "Une fois les créas et le formulaire validés, les premiers leads arrivent généralement dans les jours qui suivent le lancement. Il faut ensuite quelques semaines de données pour juger correctement la qualité et optimiser." },
      { q: 'Le budget publicitaire est-il inclus ?', a: 'Non. Le budget Meta Ads est payé directement par vous à Meta. Nos honoraires couvrent la stratégie, la production, la gestion et le suivi.' },
    ],
    related: ['meta-ads', 'lead-qualification', 'crm-whatsapp-automation'],
  },
  {
    slug: 'meta-ads',
    name: 'Meta Ads',
    short: 'Campagnes Facebook et Instagram conçues pour des leads qualifiés, pas pour le coût par lead le plus bas.',
    serviceType: 'Gestion de publicités Meta (Facebook et Instagram)',
    h1: 'Agence Meta Ads au Maroc : des campagnes Facebook et Instagram orientées clients',
    metaTitle: 'Agence Meta Ads Maroc — publicité Facebook & Instagram',
    metaDescription:
      "Gestion de campagnes Meta Ads au Maroc pour centres de formation, écoles de langues et coachs. Créas, ciblage, formulaires instantanés et Click-to-WhatsApp, optimisés pour des leads qualifiés.",
    intro:
      "Facebook et Instagram restent les canaux les plus directs pour toucher des parents, des étudiants, des professionnels et des entrepreneurs au Maroc. Mais une campagne optimisée pour le coût par lead le plus bas attire souvent des curieux. Nous construisons vos campagnes autour de ce qui compte : des conversations utiles, des rendez-vous tenus et des inscriptions.",
    problemTitle: 'Pourquoi tant de campagnes Meta déçoivent',
    problem: [
      "Le bouton « booster » donne des likes et des messages, rarement des clients.",
      "Le ciblage dérive vers des régions ou des profils qui ne peuvent pas acheter.",
      "Les créas ne qualifient pas : elles ne mentionnent ni le prix, ni le format, ni pour qui c'est.",
      "Personne ne relie les dépenses publicitaires aux inscriptions réelles.",
    ],
    forWho: [
      'Écoles et centres qui vendent des sessions, des cours ou des certifications',
      "Coachs et consultants qui ont besoin d'appels découverte avec des profils sérieux",
      'Créateurs de formations en ligne qui vendent au Maroc et à la diaspora',
      "Entreprises prêtes à investir un budget publicitaire régulier et à tester pendant plusieurs semaines",
    ],
    process: [
      { title: 'Audit du compte', text: "Pixel, compte publicitaire, historique des campagnes, formulaires existants et qualité des leads passés." },
      { title: 'Structure de test', text: "Une structure simple et lisible : peu de campagnes, des variables isolées (accroche, angle, format) pour savoir ce qui fonctionne vraiment." },
      { title: 'Créas', text: 'Vidéos verticales, accroches multiples sur un même corps de message, visuels et textes adaptés à votre audience.' },
      { title: 'Destination', text: 'Formulaire instantané qualifiant, conversation WhatsApp (Click-to-WhatsApp) ou page de destination, selon votre cycle de vente.' },
      { title: 'Optimisation', text: "Décisions basées sur le coût par lead qualifié et par rendez-vous, pas uniquement sur le coût par clic." },
    ],
    deliverables: [
      'Audit et configuration du compte publicitaire',
      "Plan de test (accroches, angles, audiences)",
      'Production ou adaptation des créas',
      'Campagnes lancées, surveillées et ajustées chaque semaine',
      'Rapport clair : dépenses, leads, leads qualifiés, coût par résultat, apprentissages',
    ],
    faqs: [
      { q: 'Formulaire instantané ou WhatsApp : que choisir ?', a: "Le formulaire instantané permet de poser des questions de qualification avant le contact. Le Click-to-WhatsApp crée une conversation immédiate, idéale quand votre équipe répond vite. Le choix dépend de votre capacité de suivi et du prix de votre offre ; nous testons souvent les deux." },
      { q: 'Quel budget minimum faut-il prévoir ?', a: "Il faut un budget suffisant pour obtenir assez de leads et prendre des décisions fiables. Nous le calculons avec vous à partir de votre objectif d'inscriptions et de votre taux de conversion actuel, avant tout lancement." },
      { q: 'Travaillez-vous avec mon compte publicitaire ?', a: 'Oui. Les campagnes tournent dans votre propre compte Business Manager : vous restez propriétaire des données, du pixel et de l’historique.' },
      { q: 'Produisez-vous les vidéos ?', a: 'Oui, nous écrivons les scripts et assurons la production et le montage des créas verticales. Vous pouvez voir des exemples dans nos travaux réalisés.' },
    ],
    related: ['lead-generation', 'conversion-funnels', 'lead-qualification'],
  },
  {
    slug: 'conversion-funnels',
    name: 'Funnels de conversion',
    short: "Le parcours entre la publicité et le rendez-vous : page, formulaire, message de confirmation et prise de RDV.",
    serviceType: 'Conception de funnels de conversion',
    h1: 'Funnels de conversion : transformer un clic en rendez-vous',
    metaTitle: 'Funnel de conversion — pages et formulaires qui convertissent',
    metaDescription:
      "Conception de funnels de conversion pour entreprises marocaines : landing page, formulaire qualifiant, confirmation WhatsApp et prise de rendez-vous. Moins de pertes entre la pub et la vente.",
    intro:
      "Entre la publicité et la vente, chaque étape fait perdre des prospects : une page lente, un formulaire flou, un message de confirmation absent, un rendez-vous jamais rappelé. Un funnel de conversion est la suite d'étapes qui guide le bon prospect vers l'action suivante et filtre les autres.",
    problemTitle: 'Où se perdent vos prospects',
    problem: [
      "La page de destination parle de vous, pas du problème de votre client.",
      'Le formulaire ne demande rien de qualifiant, ou demande trop.',
      "Après l'envoi, aucun message ne confirme ni ne rappelle la prochaine étape.",
      'Les rendez-vous sont pris, puis oubliés : beaucoup de « no-show ».',
    ],
    forWho: [
      'Offres à plus forte valeur qui nécessitent un appel ou une visite avant achat',
      'Centres qui organisent des journées portes ouvertes, des tests de niveau ou des séances découverte',
      'Coachs et consultants qui vendent via un appel stratégique',
      'Créateurs de formations qui lancent une session ou un programme',
    ],
    process: [
      { title: 'Cartographie', text: "Nous dessinons le parcours actuel, étape par étape, et mesurons où se trouvent les pertes." },
      { title: 'Message et structure', text: 'Promesse, preuves, objections, appel à l’action : une page construite pour une seule décision.' },
      { title: 'Formulaire et qualification', text: 'Les bonnes questions, dans le bon ordre, pour filtrer sans décourager.' },
      { title: 'Confirmation et rappels', text: 'Message de confirmation, rappel avant rendez-vous, et relance si le prospect ne se présente pas.' },
      { title: 'Mesure', text: 'Suivi des conversions à chaque étape pour savoir quoi améliorer en priorité.' },
    ],
    deliverables: [
      'Carte du parcours client et points de perte identifiés',
      'Landing page ou page de candidature (rédaction + structure)',
      'Formulaire qualifiant',
      'Séquence de confirmation et de rappel (WhatsApp ou e-mail)',
      'Suivi des conversions par étape',
    ],
    faqs: [
      { q: 'Ai-je besoin d’une landing page si j’utilise les formulaires Meta ?', a: "Pas toujours. Pour une offre simple, un formulaire instantané bien construit suffit. Pour une offre plus chère ou plus complexe, une page qui explique et qui filtre améliore généralement la qualité des rendez-vous." },
      { q: 'Quelle est la différence avec un site web ?', a: 'Un site présente toute votre entreprise. Un funnel est construit pour une seule offre et une seule action. Les deux sont complémentaires.' },
      { q: 'Comment réduire les rendez-vous non honorés ?', a: 'En qualifiant avant le rendez-vous, en confirmant immédiatement, en rappelant la veille et le jour même, et en rendant la prochaine étape claire et concrète.' },
    ],
    related: ['lead-qualification', 'sales-conversion', 'meta-ads'],
  },
  {
    slug: 'lead-qualification',
    name: 'Qualification des leads',
    short: 'Filtrer les curieux avant qu’ils ne coûtent du temps à votre équipe, et prioriser les prospects prêts à avancer.',
    serviceType: 'Qualification et scoring de leads',
    h1: 'Qualification des leads : passer des contacts aux opportunités',
    metaTitle: 'Qualification de leads — moins de curieux, plus de RDV',
    metaDescription:
      "Mettez en place une qualification de leads claire : questions de filtrage, critères, priorisation et scripts. Votre équipe appelle d'abord les prospects qui peuvent réellement acheter.",
    intro:
      "Un lead est une personne qui a laissé ses coordonnées. Un lead qualifié correspond à votre cible, a un besoin réel, un délai et la capacité d'investir. La qualification est ce qui sépare les deux, et c'est souvent l'étape la plus négligée.",
    problemTitle: 'Quand rien ne filtre',
    problem: [
      "Votre équipe traite tous les leads de la même façon, dans l'ordre d'arrivée.",
      'Les meilleurs prospects attendent pendant que les curieux occupent le téléphone.',
      'Personne ne sait dire combien de leads de la semaine étaient vraiment qualifiés.',
      'Les campagnes sont jugées sur le volume, pas sur la qualité.',
    ],
    forWho: [
      'Entreprises qui reçoivent déjà des leads mais convertissent peu',
      'Équipes commerciales réduites qui doivent prioriser',
      "Offres dont le prix ou le format exclut une partie du public (zone, niveau, budget)",
    ],
    process: [
      { title: 'Définir le lead qualifié', text: 'Ensemble, nous écrivons des critères précis : profil, besoin, zone, délai, budget, décisionnaire.' },
      { title: 'Questions de filtrage', text: 'Nous intégrons ces critères dans le formulaire, la conversation WhatsApp et le script d’appel.' },
      { title: 'Priorisation', text: 'Chaque lead reçoit un statut simple (chaud, à nourrir, hors cible) pour savoir qui rappeler en premier.' },
      { title: 'Boucle de retour', text: "Les statuts remontent vers les campagnes pour optimiser sur la qualité, pas seulement sur le volume." },
    ],
    deliverables: [
      'Définition écrite du lead qualifié pour votre activité',
      'Questions de qualification (formulaire, WhatsApp, appel)',
      'Grille de priorisation et statuts de pipeline',
      'Scripts de premier contact',
      'Indicateur hebdomadaire : taux de leads qualifiés',
    ],
    faqs: [
      { q: 'Quelle est la différence entre un lead et un lead qualifié ?', a: "Un lead a laissé ses coordonnées. Un lead qualifié correspond à vos critères : bonne cible, besoin réel, délai raisonnable et capacité à investir. C'est cette deuxième catégorie qui produit des clients." },
      { q: 'Ajouter des questions ne fait-il pas baisser le nombre de leads ?', a: "Si, souvent un peu. C'est voulu : moins de leads mais plus de rendez-vous utiles, et une équipe qui passe moins de temps sur des contacts sans intention." },
      { q: 'Peut-on qualifier directement sur WhatsApp ?', a: 'Oui. Une série de questions courtes, posées dès le premier échange, permet de qualifier rapidement et de passer le relais à un humain au bon moment.' },
    ],
    related: ['lead-generation', 'crm-whatsapp-automation', 'sales-conversion'],
  },
  {
    slug: 'crm-whatsapp-automation',
    name: 'CRM & automatisation WhatsApp',
    short: 'Chaque lead suivi, chaque relance faite : un pipeline clair et des messages WhatsApp au bon moment.',
    serviceType: 'Automatisation CRM et WhatsApp',
    h1: 'CRM et automatisation WhatsApp pour ne plus perdre de prospects',
    metaTitle: 'Automatisation WhatsApp & CRM pour entreprises au Maroc',
    metaDescription:
      "Mise en place d'un CRM simple et de relances WhatsApp pour centres de formation, écoles et coachs au Maroc. Leads centralisés, statuts clairs, relances régulières et reporting.",
    intro:
      "Au Maroc, la vente se fait en grande partie sur WhatsApp. C'est un avantage, à condition que les conversations ne se perdent pas entre plusieurs téléphones. Nous centralisons vos leads, définissons des statuts clairs et mettons en place des relances régulières, automatisées quand c'est pertinent et humaines quand c'est nécessaire.",
    problemTitle: 'Les signes que votre suivi fuit',
    problem: [
      'Les leads arrivent dans une boîte mail ou un fichier que personne ne consulte à temps.',
      'Les conversations WhatsApp sont éparpillées sur plusieurs téléphones personnels.',
      "On relance une fois, puis on oublie. La plupart des prospects ne sont jamais recontactés.",
      'Impossible de savoir qui a été appelé, quand, et avec quel résultat.',
    ],
    forWho: [
      'Équipes qui gèrent les prospects sur WhatsApp',
      'Centres qui reçoivent des leads de plusieurs sources (Meta, site, appels, visites)',
      'Dirigeants qui veulent voir leur pipeline sans demander un compte rendu',
    ],
    process: [
      { title: 'Centralisation', text: 'Les leads Meta et site arrivent automatiquement dans un même tableau ou CRM.' },
      { title: 'Pipeline', text: 'Des étapes simples : nouveau, contacté, qualifié, rendez-vous, inscrit, perdu.' },
      { title: 'Relances', text: 'Une séquence de relance définie (messages, notes vocales, appels) avec des délais précis.' },
      { title: 'Automatisation', text: "Accusé de réception instantané, rappels et notifications à l'équipe, via des outils adaptés à votre taille." },
      { title: 'Reporting', text: 'Un tableau de bord hebdomadaire lisible en deux minutes.' },
    ],
    deliverables: [
      'Pipeline configuré (Google Sheets, Notion ou CRM selon vos besoins)',
      'Connexion des sources de leads',
      'Séquence de relance WhatsApp rédigée',
      'Automatisations de base (confirmation, rappels, notifications)',
      'Tableau de bord et formation de l’équipe',
    ],
    faqs: [
      { q: 'Faut-il un CRM payant ?', a: "Pas forcément. Beaucoup d'équipes démarrent très bien avec un Google Sheets structuré. Nous recommandons un outil payant uniquement quand le volume ou l'équipe le justifie, en vous présentant les coûts avant toute décision." },
      { q: 'Utilisez-vous l’API WhatsApp Business ?', a: "Quand le volume le justifie, oui, via un fournisseur officiel. Nous respectons les règles de WhatsApp : pas d'envois massifs non sollicités, consentement du prospect et option de désinscription." },
      { q: 'Mon équipe devra-t-elle changer ses habitudes ?', a: 'Un peu. Le but est de garder ce qui fonctionne (la conversation WhatsApp) et d’ajouter la structure qui manque (statuts, relances, suivi).' },
    ],
    related: ['lead-qualification', 'sales-conversion', 'lead-generation'],
  },
  {
    slug: 'sales-conversion',
    name: 'Conversion commerciale',
    short: 'Scripts, process et accompagnement pour transformer davantage de rendez-vous en inscriptions et en clients.',
    serviceType: 'Optimisation de la conversion commerciale',
    h1: 'Conversion commerciale : transformer plus de leads en clients',
    metaTitle: 'Améliorer la conversion lead → client — process de vente',
    metaDescription:
      "Améliorez votre taux de conversion lead → client : scripts d'appel et WhatsApp, gestion des objections, process de rendez-vous et suivi des indicateurs commerciaux.",
    intro:
      "Doubler le budget publicitaire n'est pas la seule façon d'avoir plus de clients. Souvent, le levier le plus rapide se trouve après le lead : la vitesse de réponse, le premier message, la gestion des objections et la relance. Nous travaillons avec votre équipe sur cette partie du parcours.",
    problemTitle: 'Ce qui fait chuter la conversion',
    problem: [
      'Le premier contact arrive des heures, parfois des jours après la demande.',
      'La réponse commence par le prix, sans comprendre le besoin.',
      "Les objections (« c'est cher », « je vais réfléchir ») restent sans réponse préparée.",
      "Il n'y a pas de prochaine étape claire à la fin de l'échange.",
    ],
    forWho: [
      'Centres et écoles dont l’accueil ou le service commercial gère les prospects',
      'Coachs et consultants qui mènent eux-mêmes leurs appels de vente',
      'Entreprises qui ont des leads mais un faible taux de transformation',
    ],
    process: [
      { title: 'Écoute', text: 'Nous analysons des échanges réels (avec votre accord) et les chiffres de votre pipeline.' },
      { title: 'Scripts', text: 'Premier message, appel découverte, réponse au prix, objections fréquentes, relance.' },
      { title: 'Process', text: 'Délais de réponse, étapes du rendez-vous, critères de passage à l’étape suivante.' },
      { title: 'Suivi', text: 'Indicateurs simples : délai de réponse, taux de RDV, taux de présence, taux de conversion.' },
    ],
    deliverables: [
      'Audit de votre process de vente actuel',
      'Scripts WhatsApp et téléphone',
      'Banque de réponses aux objections',
      'Process de rendez-vous et de relance documenté',
      'Indicateurs commerciaux suivis chaque semaine',
    ],
    faqs: [
      { q: 'Comment améliorer le taux de conversion lead → client ?', a: "Répondre vite, comprendre le besoin avant de parler prix, proposer une prochaine étape concrète (test, visite, appel) et relancer de façon structurée. Ces quatre leviers ont généralement plus d'impact que n'importe quel changement de campagne." },
      { q: 'Formez-vous mon équipe ?', a: 'Oui, nous remettons les scripts et le process, et nous les passons en revue avec les personnes qui gèrent les prospects.' },
      { q: 'Prenez-vous les appels à notre place ?', a: "Non, nous ne remplaçons pas votre équipe commerciale. Nous l'outillons et l'aidons à mieux convertir les leads générés." },
    ],
    related: ['crm-whatsapp-automation', 'lead-qualification', 'conversion-funnels'],
  },
];

export const getService = (slug: string) => services.find((s) => s.slug === slug);
