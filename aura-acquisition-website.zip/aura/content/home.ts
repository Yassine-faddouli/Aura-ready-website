import type { Faq } from './services';

export const homeFaqs: Faq[] = [
  { q: "Que fait concrètement Aura Acquisition ?", a: "Nous construisons et pilotons votre système d'acquisition client : offre et message, création des publicités, campagnes Meta Ads, formulaires qualifiants, suivi WhatsApp et reporting. L'objectif est d'obtenir des rendez-vous et des clients, pas seulement des likes ou des contacts." },
  { q: 'Avec quelles entreprises travaillez-vous ?', a: "Principalement avec des centres de formation, des écoles et centres de langues, des coachs, des consultants et des créateurs de formations au Maroc. Nous travaillons mieux avec des entreprises qui ont déjà une offre qui fonctionne et la capacité de rappeler les leads rapidement." },
  { q: 'Quelle est la différence avec une agence de community management ?', a: "Une agence de community management gère votre présence sur les réseaux sociaux. Nous nous concentrons sur l'acquisition : attirer des prospects ciblés, les qualifier, les suivre et mesurer combien deviennent clients." },
  { q: 'Garantissez-vous des résultats ?', a: "Non, et méfiez-vous de ceux qui le font. Les résultats dépendent aussi de votre offre, de votre prix et de votre suivi commercial. Nous garantissons une méthode claire, une communication transparente et des chiffres réels chaque semaine." },
  { q: 'Combien faut-il prévoir comme budget ?', a: "Il y a deux postes distincts : le budget publicitaire, payé directement à Meta, et nos honoraires. Nous estimons le budget publicitaire à partir de votre objectif de clients et de vos taux de conversion lors de l'appel stratégique." },
  { q: 'Comment se passe l’appel stratégique ?', a: "Vous remplissez un court formulaire de qualification. Si votre projet correspond à ce que nous faisons, nous organisons un appel pour analyser votre acquisition actuelle et vous dire honnêtement si et comment nous pouvons aider." },
];
