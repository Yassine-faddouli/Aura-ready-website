import type { Faq } from './services';

export type Industry = {
  slug: string;
  name: string;
  short: string;
  h1: string;
  metaTitle: string;
  metaDescription: string;
  intro: string;
  challenges: { title: string; text: string }[];
  buyerConcerns: string[];
  qualification: string[];
  salesProcess: { title: string; text: string }[];
  approach: string;
  services: string[];
  faqs: Faq[];
  articles: string[];
};

export const industries: Industry[] = [
  {
    slug: 'training-centers',
    name: 'Centres de formation',
    short: 'Remplir les sessions de façon régulière, au-delà des périodes de rentrée.',
    h1: 'Acquisition de clients pour centres de formation au Maroc',
    metaTitle: 'Marketing centre de formation Maroc — acquisition d’inscrits',
    metaDescription:
      "Aura Acquisition aide les centres de formation au Maroc à générer des inscriptions régulières : Meta Ads, formulaires qualifiants, journées portes ouvertes et suivi WhatsApp structuré.",
    intro:
      "Un centre de formation vend une décision qui engage du temps et de l'argent : une formation professionnelle, une certification, un programme de plusieurs semaines. Le prospect compare, hésite, consulte sa famille ou son employeur. L'acquisition doit donc combiner visibilité, confiance et un suivi patient et organisé.",
    challenges: [
      { title: 'Saisonnalité', text: "Les inscriptions se concentrent sur quelques périodes. Entre deux rentrées, les salles se vident et la trésorerie se tend." },
      { title: 'Comparaison', text: 'Le prospect compare plusieurs centres sur le prix, la reconnaissance du diplôme, le planning et la localisation.' },
      { title: 'Cycle de décision', text: 'Entre la première demande et l’inscription, il peut se passer plusieurs semaines. Sans relance, le prospect s’inscrit ailleurs.' },
      { title: 'Accueil débordé', text: "L'équipe d'accueil gère à la fois les étudiants actuels, les appels et les messages WhatsApp. Les nouveaux prospects passent après." },
    ],
    buyerConcerns: [
      'Le diplôme ou la certification est-il reconnu ?',
      'Quels sont les horaires ? Est-ce compatible avec mon travail ou mes études ?',
      'Combien ça coûte au total, et peut-on payer en plusieurs fois ?',
      'Qui sont les formateurs ? Quels débouchés après la formation ?',
      'Puis-je visiter le centre ou assister à une séance avant de m’engager ?',
    ],
    qualification: [
      'Formation recherchée et niveau actuel',
      'Ville ou quartier (distance réaliste du centre)',
      'Disponibilité : date de démarrage souhaitée, créneaux possibles',
      'Objectif : emploi, évolution, reconversion, diplôme',
      'Capacité à financer la formation (personnellement, famille ou employeur)',
    ],
    salesProcess: [
      { title: 'Demande', text: 'Le prospect remplit un formulaire ou écrit sur WhatsApp depuis une publicité.' },
      { title: 'Premier contact rapide', text: 'Réponse dans l’heure ouvrée, avec deux ou trois questions pour comprendre le besoin.' },
      { title: 'Visite ou séance découverte', text: 'Invitation à une visite, un test de niveau ou une journée portes ouvertes.' },
      { title: 'Proposition', text: 'Planning, tarif et modalités de paiement présentés clairement.' },
      { title: 'Relance et inscription', text: 'Relances programmées jusqu’à une décision claire, positive ou négative.' },
    ],
    approach:
      "Nous combinons des vidéos tournées dans votre centre (formateurs, salles, étudiants avec leur accord) avec des campagnes Meta ciblées par zone, un formulaire qui filtre selon la formation et la disponibilité, et une séquence de relance WhatsApp que votre accueil peut suivre sans effort supplémentaire. Les événements comme les journées portes ouvertes ou les summer camps deviennent des points d'entrée pour remplir le pipeline.",
    services: ['lead-generation', 'meta-ads', 'crm-whatsapp-automation', 'sales-conversion'],
    faqs: [
      { q: 'Comment un centre de formation doit-il relancer ses prospects ?', a: "Rapidement d'abord (dans l'heure), puis selon un calendrier défini : le lendemain, à J+3, à J+7, puis avant la prochaine session. Chaque relance apporte une information utile (planning, témoignage réel, places restantes) plutôt qu'un simple « vous êtes toujours intéressé ? »." },
      { q: 'Peut-on générer des inscriptions en dehors de la rentrée ?', a: 'Oui, en structurant des offres à démarrage régulier, des sessions intensives ou des événements (portes ouvertes, ateliers, summer camps) qui donnent une raison d’agir maintenant.' },
      { q: 'Faut-il cibler tout le Maroc ?', a: 'Pour une formation en présentiel, presque jamais. Nous ciblons une zone réaliste autour du centre et surveillons la répartition géographique des leads pour éviter la dérive vers des régions non pertinentes.' },
    ],
    articles: ['relance-prospects-centre-de-formation', 'lead-vs-lead-qualifie'],
  },
  {
    slug: 'language-centers',
    name: 'Centres de langues',
    short: 'Des inscrits motivés pour vos cours de groupe et individuels, enfants comme adultes.',
    h1: 'Marketing pour centres de langues : plus d’inscriptions, moins de curieux',
    metaTitle: 'Marketing centre de langues Maroc — génération d’inscriptions',
    metaDescription:
      "Génération d'inscriptions pour centres et écoles de langues au Maroc : campagnes par profil (parents, étudiants, professionnels), test de niveau, qualification et relance WhatsApp.",
    intro:
      "Un centre de langues ne vend pas un seul produit à une seule personne. Les parents cherchent un cadre fiable pour leurs enfants, les étudiants préparent un départ ou un examen, les professionnels veulent progresser pour leur carrière. Chaque profil a sa propre motivation, son propre budget et son propre calendrier. Une seule publicité « Inscrivez-vous » ne peut pas parler à tous.",
    challenges: [
      { title: 'Plusieurs audiences', text: "Parents, étudiants, professionnels, candidats à l'expatriation : chaque profil réagit à un message différent." },
      { title: 'Comparaison sur le prix', text: "Le prospect voit d'abord un tarif horaire et compare, sans percevoir la différence de méthode ou d'encadrement." },
      { title: 'Abandon après le premier message', text: 'Beaucoup demandent le prix, reçoivent une réponse, puis disparaissent faute de prochaine étape.' },
      { title: 'Rétention', text: "Un inscrit qui abandonne après un mois coûte presque autant qu'un prospect perdu. L'expérience des premières semaines compte." },
    ],
    buyerConcerns: [
      'Quel niveau ai-je réellement ? Par où commencer ?',
      'Combien de temps faut-il pour atteindre le niveau visé ?',
      'Groupe ou cours individuels ? Combien d’élèves par groupe ?',
      'Les horaires sont-ils compatibles avec l’école ou le travail ?',
      'Le centre prépare-t-il aux examens et certifications reconnus ?',
    ],
    qualification: [
      'Langue et objectif (scolaire, voyage, études à l’étranger, carrière, examen)',
      'Profil : enfant (âge communiqué par le parent), étudiant, adulte, professionnel',
      'Niveau estimé et échéance (date d’examen, départ, entretien)',
      'Format souhaité : groupe, individuel, en ligne, présentiel',
      'Zone géographique pour les cours en présentiel',
    ],
    salesProcess: [
      { title: 'Demande ciblée', text: 'Publicité adaptée au profil (parent, étudiant, professionnel) et à la langue.' },
      { title: 'Qualification', text: 'Objectif, niveau et disponibilités recueillis dès le premier échange.' },
      { title: 'Test de niveau', text: "Une étape concrète et rassurante qui transforme la curiosité en rendez-vous." },
      { title: 'Recommandation', text: 'Le bon groupe ou le bon format, avec planning et tarif.' },
      { title: 'Inscription et suivi', text: 'Relances jusqu’à la décision, puis suivi des premières semaines pour limiter les abandons.' },
    ],
    approach:
      "Nous segmentons vos campagnes par profil et par langue, avec des messages qui parlent du résultat recherché (réussir un examen, partir étudier, évoluer au travail) plutôt que du nombre d'heures. Le test de niveau devient l'action principale : il qualifie, rassure et crée un rendez-vous. Le suivi WhatsApp est structuré pour que chaque demande de prix reçoive une prochaine étape claire.",
    services: ['meta-ads', 'lead-qualification', 'conversion-funnels', 'crm-whatsapp-automation'],
    faqs: [
      { q: 'Faut-il afficher le prix dans les publicités ?', a: "Cela dépend de votre positionnement. Afficher un prix ou un « à partir de » filtre les prospects hors budget ; ne pas l'afficher augmente le volume mais aussi les demandes non qualifiées. Nous testons les deux approches avec des données réelles." },
      { q: 'Comment toucher les parents ?', a: 'Avec des messages centrés sur l’encadrement, la sécurité, la progression mesurable et la communication avec les parents, et un ciblage adapté à ce public.' },
      { q: 'Proposez-vous des campagnes en darija ou en arabe ?', a: 'Oui. Nous produisons des créas en français, en darija et en arabe selon l’audience visée.' },
    ],
    articles: ['lead-vs-lead-qualifie', 'budget-meta-ads-maroc'],
  },
  {
    slug: 'coaches-consultants',
    name: 'Coachs & consultants',
    short: "Des appels découverte avec des profils sérieux, prêts à investir dans un accompagnement.",
    h1: 'Génération de prospects pour coachs et consultants',
    metaTitle: 'Génération de prospects pour coachs et consultants au Maroc',
    metaDescription:
      "Aura Acquisition aide les coachs et consultants à obtenir des appels découverte qualifiés : contenu qui crée la confiance, Meta Ads, page de candidature et filtrage avant l'appel.",
    intro:
      "Un coach ou un consultant vend sa propre expertise. Son temps est limité : chaque appel avec un prospect non qualifié est une heure qui ne sera pas facturée. L'enjeu n'est pas d'avoir beaucoup de contacts, mais d'avoir des conversations avec des personnes qui ont le problème, l'urgence et le budget pour être accompagnées.",
    challenges: [
      { title: 'Confiance avant tout', text: "On n'achète pas un accompagnement à un inconnu. Le prospect doit d'abord comprendre votre approche et vous faire confiance." },
      { title: 'Temps du fondateur', text: "Vous êtes à la fois l'expert, le créateur de contenu et le commercial. Les appels inutiles coûtent cher." },
      { title: 'Dépendance au réseau', text: 'Le bouche-à-oreille fonctionne, mais il est irrégulier et difficile à accélérer.' },
      { title: 'Offre floue', text: "« Coaching » ou « conseil » ne dit pas quel problème vous résolvez, pour qui, et avec quel résultat." },
    ],
    buyerConcerns: [
      'Cette personne a-t-elle déjà aidé quelqu’un dans ma situation ?',
      'Comment se déroule concrètement l’accompagnement ?',
      'Combien de temps avant de voir un changement ?',
      'Le prix est-il justifié par rapport à ce que je vais obtenir ?',
    ],
    qualification: [
      'Situation actuelle et problème précis à résoudre',
      'Objectif et échéance',
      'Ce qui a déjà été essayé',
      'Disponibilité pour s’engager dans un accompagnement',
      'Capacité à investir dans la gamme de prix de l’offre',
    ],
    salesProcess: [
      { title: 'Contenu', text: 'Vidéos et formats (podcast, conseils) qui montrent votre manière de penser et de travailler.' },
      { title: 'Publicité', text: 'Amplification des contenus qui fonctionnent et campagnes vers une page de candidature.' },
      { title: 'Candidature', text: 'Un formulaire qui fait réfléchir le prospect et filtre avant l’appel.' },
      { title: 'Appel découverte', text: 'Un appel structuré : diagnostic, objectif, proposition, prochaine étape.' },
      { title: 'Suivi', text: 'Relance des prospects qualifiés qui n’ont pas encore décidé.' },
    ],
    approach:
      "Nous partons de votre expertise pour produire un contenu qui crée la confiance (formats podcast, vidéos courtes, prises de position), puis nous l'amplifions avec Meta Ads vers une page de candidature. Le prospect arrive à l'appel en connaissant déjà votre approche, et vous savez avant de décrocher s'il correspond à votre offre.",
    services: ['lead-generation', 'conversion-funnels', 'lead-qualification', 'sales-conversion'],
    faqs: [
      { q: 'Faut-il beaucoup d’abonnés pour vendre un accompagnement ?', a: "Non. Une audience réduite mais ciblée, combinée à des publicités et à un process de candidature clair, peut suffire à remplir un agenda d'appels qualifiés." },
      { q: 'Dois-je apparaître moi-même dans les vidéos ?', a: "C'est fortement recommandé : vous vendez votre expertise, et la confiance passe par votre visage et votre voix. Nous préparons les scripts et accompagnons le tournage pour que ce soit simple." },
      { q: 'Travaillez-vous avec les consultants B2B ?', a: 'Oui, si votre offre et votre cible s’y prêtent. Nous en discutons lors de l’appel stratégique pour vérifier que Meta est le bon canal.' },
    ],
    articles: ['lead-vs-lead-qualifie', 'budget-meta-ads-maroc'],
  },
  {
    slug: 'course-creators',
    name: 'Créateurs de formations',
    short: 'Transformer une audience en inscriptions, à chaque lancement et entre les lancements.',
    h1: 'Acquisition pour créateurs de formations et éducation en ligne',
    metaTitle: 'Créateurs de formations en ligne — acquisition d’élèves au Maroc',
    metaDescription:
      "Acquisition d'élèves pour créateurs de formations et entreprises d'éducation en ligne au Maroc : contenu, Meta Ads, webinaire ou appel, qualification et suivi WhatsApp.",
    intro:
      "Une formation en ligne se vend à distance, souvent sans rencontre physique. Le prospect doit croire en vous, en votre méthode et en sa propre capacité à aller au bout. Les créateurs qui réussissent ne comptent pas uniquement sur leurs abonnés : ils ont un système qui amène de nouvelles personnes, les éduque et les accompagne jusqu'à l'inscription.",
    challenges: [
      { title: 'Audience ≠ acheteurs', text: 'Des milliers d’abonnés ne garantissent pas des ventes. Beaucoup consomment le contenu gratuit sans passer à l’achat.' },
      { title: 'Lancements épuisants', text: 'Tout repose sur quelques jours de lancement intenses, puis le chiffre d’affaires retombe.' },
      { title: 'Paiement et confiance', text: 'Paiement en ligne, peur de l’arnaque, doutes sur la valeur : les objections sont nombreuses.' },
      { title: 'Suivi manuel', text: 'Les demandes arrivent en DM et sur WhatsApp, et le suivi repose sur la mémoire.' },
    ],
    buyerConcerns: [
      'Est-ce que cette formation est faite pour mon niveau ?',
      'Vais-je avoir le temps de la suivre ?',
      'Y a-t-il un accompagnement ou suis-je seul face aux vidéos ?',
      'Comment payer, et que se passe-t-il si cela ne me convient pas ?',
    ],
    qualification: [
      'Niveau de départ et objectif',
      'Temps disponible par semaine',
      'Format préféré (autonome, accompagné, en groupe)',
      'Pays et moyen de paiement',
      'Capacité à investir dans la formation',
    ],
    salesProcess: [
      { title: 'Attirer', text: 'Contenu et publicités qui parlent d’un problème précis de votre élève idéal.' },
      { title: 'Éduquer', text: 'Webinaire, mini-formation, live ou série de vidéos qui démontrent votre méthode.' },
      { title: 'Qualifier', text: 'Questions courtes pour orienter vers la bonne offre.' },
      { title: 'Convertir', text: 'Appel ou conversation WhatsApp pour les offres premium, paiement direct pour les autres.' },
      { title: 'Suivre', text: 'Relances structurées et réactivation des prospects des lancements précédents.' },
    ],
    approach:
      "Nous construisons un parcours qui fonctionne en continu, et pas seulement pendant les lancements : contenus d'acquisition, campagnes Meta vers une étape d'éducation, qualification courte et suivi WhatsApp pour les offres qui le méritent. Chaque lancement s'appuie sur une base de prospects déjà qualifiés.",
    services: ['meta-ads', 'conversion-funnels', 'crm-whatsapp-automation', 'sales-conversion'],
    faqs: [
      { q: 'Webinaire ou appel de vente : que choisir ?', a: "Pour une formation à prix accessible, une étape d'éducation (webinaire, mini-série) suivie d'un paiement direct suffit souvent. Pour un programme accompagné plus cher, un appel ou une conversation WhatsApp augmente nettement la conversion." },
      { q: 'Pouvez-vous cibler la diaspora marocaine ?', a: "Oui, Meta permet de cibler des personnes vivant à l'étranger selon plusieurs critères. Nous vérifions avec vous que votre offre, votre prix et vos moyens de paiement sont adaptés à cette audience." },
      { q: 'Faut-il une plateforme de formation particulière ?', a: "Non. Nous travaillons avec la plateforme que vous utilisez déjà, tant qu'elle permet de suivre les inscriptions." },
    ],
    articles: ['budget-meta-ads-maroc', 'lead-vs-lead-qualifie'],
  },
];

export const getIndustry = (slug: string) => industries.find((i) => i.slug === slug);
