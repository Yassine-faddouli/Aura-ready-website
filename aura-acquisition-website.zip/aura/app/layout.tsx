import type { Metadata, Viewport } from 'next';
import '@fontsource-variable/inter';
import '@fontsource/space-grotesk/500.css';
import '@fontsource/space-grotesk/700.css';
import './globals.css';
import { site } from '@/lib/site';
import { organizationSchema } from '@/lib/seo';
import { headingNowCss } from '@/lib/fonts';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { JsonLd } from '@/components/JsonLd';

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name} — Agence d’acquisition client au Maroc`, template: `%s | ${site.name}` },
  description: site.description,
  applicationName: site.name,
  authors: [{ name: site.founder.name }],
  creator: site.name,
  formatDetection: { telephone: false },
  icons: { icon: [{ url: '/favicon.ico', sizes: 'any' }, { url: '/icon.svg', type: 'image/svg+xml' }], apple: '/apple-touch-icon.png' },
  // Google Search Console: paste your verification token here (or verify via DNS — recommended)
  verification: { google: process.env.NEXT_PUBLIC_GSC_VERIFICATION || undefined },
};

export const viewport: Viewport = { themeColor: '#080808', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const heading = headingNowCss();
  return (
    <html lang="fr-MA" data-ga={site.gaId || undefined}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: "document.documentElement.classList.add('js')" }} />
        {heading.preload ? <link rel="preload" href={heading.preload} as="font" type="font/woff2" crossOrigin="anonymous" /> : null}
        {heading.css ? <style dangerouslySetInnerHTML={{ __html: heading.css }} /> : null}
        <script src="/site.js" defer />
      </head>
      <body>
        <a className="skip" href="#main">Aller au contenu</a>
        <JsonLd data={organizationSchema()} />
        <Header />
        <main id="main">{children}</main>
        <Footer />
        {site.gaId ? (
          <div className="cookie" role="dialog" aria-label="Consentement aux cookies" data-cookie>
            Nous utilisons des cookies de mesure d’audience uniquement avec votre accord. <a href="/cookie-policy/">En savoir plus</a>
            <div className="btn-row"><button className="btn" data-accept type="button">Accepter</button><button className="btn btn-ghost" data-decline type="button">Refuser</button></div>
          </div>
        ) : null}
      </body>
    </html>
  );
}
