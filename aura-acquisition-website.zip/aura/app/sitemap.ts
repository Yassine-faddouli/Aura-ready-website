import type { MetadataRoute } from 'next';
import { absUrl } from '@/lib/site';
import { services } from '@/content/services';
import { industries } from '@/content/industries';
import { articles } from '@/content/articles';
import { publishedCaseStudies } from '@/content/case-studies';

export const dynamic = 'force-static';

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date().toISOString().slice(0, 10);
  const u = (path: string, priority: number, lastModified = now) => ({ url: absUrl(path), lastModified, priority });
  return [
    u('/', 1),
    u('/services/', 0.9), ...services.map((s) => u(`/services/${s.slug}/`, 0.9)),
    u('/industries/', 0.8), ...industries.map((i) => u(`/industries/${i.slug}/`, 0.8)),
    u('/results/', 0.7), ...publishedCaseStudies.map((c) => u(`/results/${c.slug}/`, 0.7)),
    u('/about/', 0.6),
    u('/insights/', 0.7), ...articles.map((a) => u(`/insights/${a.slug}/`, 0.7, a.updated)),
    u('/work-with-us/', 0.8), u('/contact/', 0.6),
    u('/privacy-policy/', 0.2), u('/legal-notice/', 0.2), u('/cookie-policy/', 0.1),
  ];
}
