import Link from 'next/link';
import { pageMeta } from '@/lib/seo';
import { site } from '@/lib/site';
import { services } from '@/content/services';
import { industries } from '@/content/industries';
import { work } from '@/content/work';
import { homeFaqs } from '@/content/home';
import { Arrow, CtaBand, CtaButtons, FaqList, SectionHead, WorkVideo } from '@/components/ui';

export const metadata = pageMeta({
  title: 'Aura Acquisition — Agence de génération de leads qualifiés au Maroc',
  absoluteTitle: true,
  description:
    'Aura Acquisition aide les centres de formation, écoles de langues, coachs et créateurs de formations au Maroc à générer des leads qualifiés : Meta Ads, funnels, qualification et suivi WhatsApp.',
  path: '/',
});

const method = [
  { title: 'Diagnostic & offre', text: "Nous analysons votre offre, vos prix, vos anciens leads et votre process de vente. Puis nous clarifions la promesse et le profil du client idéal." },
  { title: 'Contenu & créas', text: 'Scripts, tournage et montage de vidéos verticales pensées pour attirer la bonne cible, et filtrer les autres.' },
  { title: 'Campagnes Meta Ads', text: 'Facebook et Instagram, avec une structure de test simple : plusieurs accroches, un même message, des décisions basées sur les données.' },
  { title: 'Qualification', text: 'Formulaire ou conversation WhatsApp avec les bonnes questions : besoin, zone, délai, capacité à investir.' },
  { title: 'Suivi & conversion', text: "Pipeline clair, relances programmées, scripts pour votre équipe et un rapport hebdomadaire centré sur les rendez-vous et les clients." },
];

export default function Home() {
  const reel = work.slice(0, 9);
  const cols = [reel.slice(0, 3), reel.slice(3, 6), reel.slice(6, 9)];
  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <p className="eyebrow">Agence d’acquisition client · {site.city}, Maroc</p>
            <h1>Nous transformons vos contenus et vos publicités en <em>clients qualifiés.</em></h1>
            <p className="lead">
              Aura Acquisition construit des systèmes de génération de leads pour les centres de formation, écoles de langues, coachs et créateurs de formations au Maroc&nbsp;: publicités Meta, funnels de conversion, qualification et suivi WhatsApp. L’objectif n’est pas plus de messages. Ce sont plus de rendez-vous et plus d’inscriptions.
            </p>
            <CtaButtons />
            <div className="hero-meta" aria-label="Ce que nous faisons">
              <span>Meta Ads</span><span>Funnels de conversion</span><span>Qualification</span><span>Suivi WhatsApp</span>
            </div>
          </div>
          <div className="reel" aria-hidden="true">
            {cols.map((c, i) => (
              <div className="reel-col" key={i}>
                {[...c, ...c].map((w, j) => <img key={j} src={`/work/${w.id}.jpg`} alt="" width={540} height={960} loading={i === 0 && j < 2 ? 'eager' : 'lazy'} decoding="async" />)}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CLIENT FIT */}
      <section className="section light">
        <div className="container">
          <SectionHead eyebrow="Pour qui" title="Nous travaillons avec les entreprises qui vendent de l’expertise et de la formation." lead="Des offres qui demandent de la confiance avant l’achat, un suivi humain et une décision réfléchie. C’est là qu’un système d’acquisition fait la différence." />
          <div className="grid g4">
            {industries.map((ind, i) => (
              <Link key={ind.slug} href={`/industries/${ind.slug}/`} className="card">
                <span className="idx">0{i + 1}</span>
                <h3>{ind.name}</h3>
                <p>{ind.short}</p>
                <span className="more">Voir l’approche <Arrow /></span>
              </Link>
            ))}
          </div>
          <div className="two-col" style={{ marginTop: 'clamp(56px, 7vw, 96px)' }}>
            <div>
              <p className="col-title">Nous sommes un bon choix si</p>
              <ul className="ticks check">
                <li>Votre offre fonctionne déjà et vos clients en sont satisfaits.</li>
                <li>Vous pouvez rappeler un lead rapidement, vous ou votre équipe.</li>
                <li>Vous voulez des chiffres réels : leads qualifiés, rendez-vous, clients.</li>
                <li>Vous êtes prêt à investir un budget publicitaire régulier.</li>
              </ul>
            </div>
            <div>
              <p className="col-title">Nous ne sommes pas le bon choix si</p>
              <ul className="ticks cross">
                <li>Vous cherchez uniquement des abonnés ou des likes.</li>
                <li>Vous attendez des résultats garantis sans tester.</li>
                <li>Personne ne peut traiter les leads reçus.</li>
                <li>L’offre elle-même n’est pas encore définie.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="section">
        <div className="container">
          <SectionHead eyebrow="Services" title="Chaque étape entre l’inconnu et le client." lead="Vous pouvez nous confier tout le système ou la partie qui bloque aujourd’hui. Chaque service est pensé pour s’intégrer aux autres." />
          <div className="grid g3">
            {services.map((s, i) => (
              <Link key={s.slug} href={`/services/${s.slug}/`} className="card">
                <span className="idx">0{i + 1}</span>
                <h3>{s.name}</h3>
                <p>{s.short}</p>
                <span className="more">En savoir plus <Arrow /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* METHOD */}
      <section className="section">
        <div className="container">
          <div className="two-col wide-left sticky-left">
            <div>
              <p className="eyebrow">Méthode</p>
              <h2>Le Qualified Pipeline System.</h2>
              <p className="lead" style={{ marginTop: 24 }}>Notre méthode relie le contenu, la publicité, la qualification et le suivi dans un seul système mesurable. Chaque étape alimente la suivante, et chaque semaine les chiffres disent quoi améliorer.</p>
            </div>
            <ol className="steps" style={{ borderTop: 0 }}>
              {method.map((m) => (
                <li key={m.title} style={{ gridTemplateColumns: '64px 1fr', display: 'grid' }}>
                  <div><h3 style={{ marginBottom: 8 }}>{m.title}</h3><p>{m.text}</p></div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* PROOF */}
      <section className="section light">
        <div className="container">
          <SectionHead eyebrow="Travaux réalisés" title="Des créas produites pour de vrais clients." lead="Une sélection de vidéos que nous avons écrites, tournées ou montées pour des centres de formation, des écoles et des coachs au Maroc. Les études de cas chiffrées sont publiées uniquement avec des données vérifiées et l’accord du client." />
          <div className="work-grid five">
            {work.slice(0, 8).map((w) => <WorkVideo key={w.id} item={w} />)}
          </div>
          <p style={{ marginTop: 40 }}><Link href="/results/" className="link">Voir tous les travaux et notre approche des résultats →</Link></p>
        </div>
      </section>

      {/* LEADS VS QUALIFIED */}
      <section className="section">
        <div className="container">
          <SectionHead eyebrow="La différence" title="Générer des leads n’est pas générer des opportunités." lead="Un formulaire rempli n’est pas un client. Nous construisons tout le système autour de la seconde colonne." />
          <div className="compare">
            <div>
              <h3>Un lead</h3>
              <ul className="ticks cross">
                <li>A laissé un numéro ou envoyé « prix ? »</li>
                <li>Profil, zone et budget inconnus</li>
                <li>Traité dans l’ordre d’arrivée, quand quelqu’un a le temps</li>
                <li>Mesuré par le coût par lead</li>
              </ul>
            </div>
            <div className="inverse">
              <h3>Une opportunité qualifiée</h3>
              <ul className="ticks check">
                <li>Correspond à votre client idéal et à votre zone</li>
                <li>A exprimé un besoin, un délai et une capacité à investir</li>
                <li>Rappelée rapidement, avec son contexte, selon une séquence définie</li>
                <li>Mesurée par le coût par rendez-vous et par client</li>
              </ul>
            </div>
          </div>
          <p style={{ marginTop: 32 }}><Link href="/insights/lead-vs-lead-qualifie/" className="link">Lire : lead ou lead qualifié, la différence qui change votre rentabilité →</Link></p>
        </div>
      </section>

      {/* FAQ */}
      <section className="section">
        <div className="container two-col sticky-left">
          <div>
            <p className="eyebrow">Questions fréquentes</p>
            <h2>Ce que les dirigeants nous demandent.</h2>
          </div>
          <FaqList faqs={homeFaqs} />
        </div>
      </section>

      <CtaBand />
    </>
  );
}
