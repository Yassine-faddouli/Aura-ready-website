import Link from 'next/link';
import { pageMeta } from '@/lib/seo';
import { work } from '@/content/work';
import { publishedCaseStudies } from '@/content/case-studies';
import { Arrow, CtaBand, PageHero, SectionHead, WorkVideo } from '@/components/ui';

export const metadata = pageMeta({
  title: 'Résultats et travaux réalisés',
  description: 'Créas vidéo produites par Aura Acquisition pour des centres de formation, écoles et coachs au Maroc, et notre politique de publication des résultats : uniquement des chiffres vérifiés.',
  path: '/results/',
});

export default function ResultsPage() {
  return (
    <>
      <PageHero crumbs={[{ name: 'Résultats', path: '/results/' }]} eyebrow="Résultats" title="Des preuves, pas des promesses."
        lead="Nous publions uniquement des résultats vérifiés, avec l’accord écrit du client, la période concernée et la source des chiffres. En attendant la publication de nos études de cas, voici le travail créatif réalisé pour nos clients." />

      {publishedCaseStudies.length ? (
        <section className="section">
          <div className="container">
            <SectionHead eyebrow="Études de cas" title="Études de cas" split={false} />
            <div className="grid g2">
              {publishedCaseStudies.map((c) => (
                <Link key={c.slug} href={`/results/${c.slug}/`} className="card"><span className="idx">{c.industry} · {c.period}</span><h3>{c.client}</h3><p>{c.summary}</p><span className="more">Lire l’étude <Arrow /></span></Link>
              ))}
            </div>
          </div>
        </section>
      ) : null}

      <section className="section">
        <div className="container">
          <SectionHead eyebrow="Travaux réalisés" title="Créas produites pour nos clients" lead="Vidéos verticales pour Meta Ads et réseaux sociaux : publicités d’inscription, événements, présentations d’établissement et formats de marque. Les noms des clients sont affichés uniquement avec leur autorisation." />
          <div className="work-grid five">{work.map((w) => <WorkVideo key={w.id} item={w} />)}</div>
        </div>
      </section>

      <section className="section light">
        <div className="container two-col">
          <div><p className="eyebrow">Notre standard</p><h2>Comment nous présentons un résultat</h2></div>
          <ul className="ticks check">
            <li>Le client, le secteur et la période exacte</li>
            <li>La situation de départ et le problème à résoudre</li>
            <li>Ce qui a été fait : offre, créas, campagnes, qualification, suivi</li>
            <li>Des chiffres issus de sources vérifiables (CRM, Meta Ads, registre d’inscriptions)</li>
            <li>Ce qui a fonctionné, ce qui n’a pas fonctionné et ce que nous en retenons</li>
          </ul>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
