import { notFound } from 'next/navigation';
import { pageMeta } from '@/lib/seo';
import { caseStudies } from '@/content/case-studies';
import { CtaBand, PageHero } from '@/components/ui';

export const dynamicParams = false;
// Drafts are generated so they can be reviewed, but they are noindex and excluded from the sitemap and all links.
export function generateStaticParams() { return caseStudies.map((c) => ({ slug: c.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const slug = (await params).slug;
  const cs = caseStudies.find((x) => x.slug === slug);
  if (!cs) return {};
  return pageMeta({ title: cs.status === 'draft' ? `Brouillon — ${cs.client}` : `${cs.client} — étude de cas`, description: cs.summary, path: `/results/${cs.slug}/`, noindex: cs.status !== 'published' });
}

export default async function CaseStudyPage({ params }: { params: Promise<{ slug: string }> }) {
  const slug = (await params).slug;
  const c = caseStudies.find((x) => x.slug === slug);
  if (!c) notFound();
  const path = `/results/${c.slug}/`;
  return (
    <>
      <PageHero crumbs={[{ name: 'Résultats', path: '/results/' }, { name: c.client, path }]} eyebrow={`${c.industry} · ${c.period}`} title={c.client} lead={c.summary}>
        {c.status === 'draft' ? <div className="banner-draft"><strong>Modèle non publié.</strong> Cette page n’est pas indexée et n’est liée nulle part. Remplacez chaque champ entre crochets par des données vérifiées, obtenez l’accord écrit du client, puis passez <code>status</code> à <code>published</code> dans <code>content/case-studies.ts</code>.</div> : null}
      </PageHero>
      <section className="section">
        <div className="container">
          <div className="grid g3" style={{ marginBottom: 'clamp(56px, 7vw, 96px)' }}>
            {c.metrics.map((m) => <div key={m.label} className="card"><span className="idx">{m.label}</span><p className="display" style={{ fontSize: 'clamp(2rem,4vw,3.2rem)', color: 'inherit' }}>{m.value}</p><p style={{ fontSize: '0.85rem' }}>Source : {m.source}</p></div>)}
          </div>
          <div className="prose" style={{ margin: '0 auto' }}>
            <h2>Situation de départ</h2><p>{c.starting}</p>
            <h2>Le défi</h2><p>{c.challenge}</p>
            <h2>Stratégie</h2><ul>{c.strategy.map((s) => <li key={s}>{s}</li>)}</ul>
            <h2>Mise en œuvre</h2><ol>{c.implementation.map((s) => <li key={s}>{s}</li>)}</ol>
            <h2>Résultats</h2><p>{c.results}</p>
            <h2>Ce que nous en retenons</h2><ul>{c.lessons.map((s) => <li key={s}>{s}</li>)}</ul>
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
