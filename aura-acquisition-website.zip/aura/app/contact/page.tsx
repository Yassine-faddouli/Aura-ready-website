import Link from 'next/link';
import { pageMeta } from '@/lib/seo';
import { site, waLink } from '@/lib/site';
import { PageHero } from '@/components/ui';
import { ContactForm } from '@/components/Forms';

export const metadata = pageMeta({
  title: 'Contact — agence d’acquisition à Casablanca',
  description: 'Contactez Aura Acquisition, agence d’acquisition client à Casablanca : WhatsApp ou formulaire. Réponse sous 1 à 2 jours ouvrés.',
  path: '/contact/',
});

export default function ContactPage() {
  return (
    <>
      <PageHero crumbs={[{ name: 'Contact', path: '/contact/' }]} eyebrow="Contact" title="Parlons de votre acquisition."
        lead="Une question, un projet, une collaboration ? Écrivez-nous. Pour un projet d’acquisition client, le formulaire de qualification est le moyen le plus rapide d’obtenir un appel stratégique." />
      <section className="section">
        <div className="container two-col wide-left">
          <ContactForm />
          <div className="stack">
            <div>
              <p className="col-title">WhatsApp</p>
              <p><a className="link" href={waLink('Bonjour Aura Acquisition, je vous contacte depuis votre site.')} target="_blank" rel="noopener">{site.whatsappDisplay}</a></p>
            </div>
            {site.email ? <div><p className="col-title">E-mail</p><p><a className="link" href={`mailto:${site.email}`}>{site.email}</a></p></div> : null}
            <div>
              <p className="col-title">Ville</p>
              <p>{site.city}, {site.country}. Nous travaillons avec des clients dans tout le Maroc, principalement à distance.</p>
            </div>
            <div>
              <p className="col-title">Après votre message</p>
              <ul className="ticks">
                <li>Nous lisons chaque message et répondons sous 1 à 2 jours ouvrés.</li>
                <li>Si votre demande concerne un projet d’acquisition, nous vous proposerons de remplir le court formulaire de qualification.</li>
                <li>Aucune liste de diffusion : vos coordonnées servent uniquement à vous répondre.</li>
              </ul>
            </div>
            <div style={{ paddingTop: 12 }}><Link href="/work-with-us/" className="btn btn-ghost">Réserver un appel stratégique</Link></div>
          </div>
        </div>
      </section>
    </>
  );
}
