import { pageMeta } from '@/lib/seo';
import { site } from '@/lib/site';
import { PageHero } from '@/components/ui';

export const metadata = pageMeta({ title: 'Politique de confidentialité', description: 'Comment Aura Acquisition collecte, utilise et protège vos données personnelles, conformément à la loi marocaine 09-08.', path: '/privacy-policy/' });
const P = ({ children }: { children: React.ReactNode }) => <span className="placeholder">{children}</span>;

export default function Privacy() {
  return (
    <>
      <PageHero crumbs={[{ name: 'Politique de confidentialité', path: '/privacy-policy/' }]} title="Politique de confidentialité" lead="Dernière mise à jour : 29 octobre 2026" />
      <section className="section light">
        <div className="container prose">
          <p className="muted">Ce texte est un modèle à faire valider. Les éléments surlignés doivent être complétés ; la déclaration auprès de la CNDP doit être effectuée avant la collecte de données.</p>
          <h2>Responsable du traitement</h2>
          <p>{site.name} ({site.legalForm}), représentée par {site.founder.name}, {site.city}, Maroc. Contact : WhatsApp {site.whatsappDisplay}{site.email ? ` ou ${site.email}` : ''}.</p>
          <h2>Données collectées</h2>
          <p>Uniquement les données que vous nous transmettez via les formulaires du site ou par WhatsApp : nom, adresse e-mail, téléphone, entreprise, site web ou profil social, secteur, informations sur votre activité et votre projet, moyen de contact préféré.</p>
          <h2>Finalités</h2>
          <ul><li>Répondre à votre demande et vous recontacter</li><li>Évaluer si nos services correspondent à votre besoin et préparer un appel stratégique</li><li>Établir une proposition commerciale si vous le souhaitez</li></ul>
          <p>Nous n’utilisons pas vos données à des fins de prospection non sollicitée et ne les vendons jamais.</p>
          <h2>Base légale</h2>
          <p>Votre consentement, recueilli dans le formulaire, conformément à la loi n° 09-08 relative à la protection des personnes physiques à l’égard du traitement des données à caractère personnel.</p>
          <h2>Destinataires et outils</h2>
          <p>Vos données sont accessibles uniquement à l’équipe d’{site.name}. Elles peuvent être traitées par des outils techniques : <P>[outil de réception des formulaires / CRM, ex. Make, Google Sheets, HubSpot]</P>, WhatsApp (Meta) si vous choisissez ce canal, et l’hébergeur du site. Certains de ces prestataires peuvent être situés hors du Maroc.</p>
          <h2>Durée de conservation</h2>
          <p>Les données des prospects sont conservées au maximum <P>[24 mois]</P> après le dernier échange, puis supprimées.</p>
          <h2>Vos droits</h2>
          <p>Vous disposez d’un droit d’accès, de rectification et d’opposition sur vos données. Pour l’exercer, contactez-nous via WhatsApp{site.email ? ' ou par e-mail' : ''}. Vous pouvez également adresser une réclamation à la Commission Nationale de contrôle de la protection des Données à caractère Personnel (CNDP).</p>
          <p>Déclaration CNDP : <P>[numéro de récépissé]</P></p>
          <h2>Cookies</h2>
          <p>Voir la <a href="/cookie-policy/">politique cookies</a>.</p>
        </div>
      </section>
    </>
  );
}
