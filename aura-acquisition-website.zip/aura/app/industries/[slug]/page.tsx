import Link from 'next/link';
import { notFound } from 'next/navigation';
import { pageMeta } from '@/lib/seo';
import { industries, getIndustry } from '@/content/industries';
import { getService } from '@/content/services';
import { getArticle } from '@/content/articles';
import { Arrow, CtaBand, CtaButtons, FaqList, PageHero } from '@/components/ui';

export const dynamicParams = false;
export function generateStaticParams() { return industries.map((i) => ({ slug: i.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const i = getIndustry((await params).slug);
  if (!i) return {};
  return pageMeta({ title: i.metaTitle, description: i.metaDescription, path: `/industries/${i.slug}/` });
}

export default async function IndustryPage({ params }: { params: Promise<{ slug: string }> }) {
  const ind = getIndustry((await params).slug);
  if (!ind) notFound();
  const path = `/industries/${ind.slug}/`;
  return (
    <>
      <PageHero crumbs={[{ name: 'Secteurs', path: '/industries/' }, { name: ind.name, path }]} eyebrow={ind.name} title={ind.h1} lead={ind.intro}>
        <CtaButtons secondary={{ href: '#approche', label: 'Voir notre approche' }} />
      </PageHero>

      <section className="section">
        <div className="container">
          <div className="section-head"><div><p className="eyebrow">Les défis</p><h2>Ce qui rend l’acquisition difficile</h2></div></div>
          <div className="grid g4">
            {ind.challenges.map((c, k) => <div key={c.title} className="card"><span className="idx">0{k + 1}</span><h3>{c.title}</h3><p>{c.text}</p></div>)}
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container two-col">
          <div>
            <p className="col-title">Ce que vos prospects se demandent</p>
            <h2 style={{ fontSize: 'clamp(1.7rem, 3vw, 2.5rem)', marginBottom: 28 }}>Les questions avant d’acheter</h2>
            <ul className="ticks">{ind.buyerConcerns.map((c) => <li key={c}>{c}</li>)}</ul>
          </div>
          <div>
            <p className="col-title">Ce qui qualifie un prospect</p>
            <h2 style={{ fontSize: 'clamp(1.7rem, 3vw, 2.5rem)', marginBottom: 28 }}>Les critères de qualification</h2>
            <ul className="ticks check">{ind.qualification.map((c) => <li key={c}>{c}</li>)}</ul>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head"><div><p className="eyebrow">Processus de vente</p><h2>Le parcours qui fonctionne</h2></div></div>
          <ol className="steps">{ind.salesProcess.map((st) => <li key={st.title}><h3>{st.title}</h3><p>{st.text}</p></li>)}</ol>
        </div>
      </section>

      <section className="section" id="approche">
        <div className="container two-col">
          <div><p className="eyebrow">Notre approche</p><h2>Comment Aura vous aide</h2></div>
          <div>
            <p className="lead" style={{ color: 'inherit' }}>{ind.approach}</p>
            <ul className="pill-list" style={{ marginTop: 28 }}>
              {ind.services.map((sl) => { const s = getService(sl)!; return <li key={sl}><Link className="badge" style={{ textDecoration: 'none' }} href={`/services/${sl}/`}>{s.name}</Link></li>; })}
            </ul>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container two-col sticky-left">
          <div><p className="eyebrow">Questions fréquentes</p><h2>{ind.name} : vos questions</h2></div>
          <FaqList faqs={ind.faqs} />
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <div className="section-head"><div><p className="eyebrow">Ressources</p><h2>À lire</h2></div></div>
          <div className="grid g2">
            {ind.articles.map((a) => { const art = getArticle(a)!; return (
              <Link key={a} href={`/insights/${a}/`} className="card"><span className="idx">{art.category}</span><h3>{art.title}</h3><p>{art.description}</p><span className="more">Lire <Arrow /></span></Link>
            ); })}
          </div>
        </div>
      </section>
      <CtaBand title="Construisons votre pipeline de clients qualifiés." />
    </>
  );
}
