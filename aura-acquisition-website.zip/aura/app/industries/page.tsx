import Link from 'next/link';
import { pageMeta } from '@/lib/seo';
import { industries } from '@/content/industries';
import { Arrow, CtaBand, PageHero } from '@/components/ui';

export const metadata = pageMeta({
  title: 'Secteurs : formation, langues, coachs, créateurs de formations',
  description: 'Aura Acquisition se spécialise dans l’acquisition client pour les centres de formation, centres de langues, coachs, consultants et créateurs de formations au Maroc.',
  path: '/industries/',
});

export default function IndustriesPage() {
  return (
    <>
      <PageHero crumbs={[{ name: 'Secteurs', path: '/industries/' }]} eyebrow="Secteurs" title="Spécialisés dans l’éducation et l’expertise."
        lead="Nous travaillons avec un nombre limité de secteurs pour en connaître les cycles de décision, les objections et les process de vente. Chaque page détaille notre approche." />
      <section className="section">
        <div className="container">
          <div className="grid g2">
            {industries.map((ind, i) => (
              <Link key={ind.slug} href={`/industries/${ind.slug}/`} className="card" style={{ minHeight: 300 }}>
                <span className="idx">0{i + 1}</span>
                <h2 style={{ fontSize: 'clamp(1.7rem, 2.8vw, 2.4rem)', marginTop: 18 }}>{ind.name}</h2>
                <p>{ind.short}</p>
                <span className="more">Voir l’approche <Arrow /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
