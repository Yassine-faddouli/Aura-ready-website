import Link from 'next/link';
import { pageMeta } from '@/lib/seo';
import { articles } from '@/content/articles';
import { Arrow, CtaBand, PageHero } from '@/components/ui';

export const metadata = pageMeta({
  title: 'Ressources : génération de leads, Meta Ads et conversion',
  description: 'Guides pratiques sur la génération de leads au Maroc, Meta Ads, la qualification des prospects, le suivi WhatsApp et l’acquisition pour les entreprises de formation.',
  path: '/insights/',
});

const fmt = (d: string) => new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

export default function InsightsPage() {
  const sorted = [...articles].sort((a, b) => b.published.localeCompare(a.published));
  return (
    <>
      <PageHero crumbs={[{ name: 'Ressources', path: '/insights/' }]} eyebrow="Ressources" title="Des guides concrets pour mieux acquérir vos clients."
        lead="Méthodes, calculs et process applicables directement, pour les dirigeants de centres de formation, d’écoles de langues et les coachs au Maroc." />
      <section className="section">
        <div className="container">
          <div className="grid g3">
            {sorted.map((a) => (
              <Link key={a.slug} href={`/insights/${a.slug}/`} className="card" style={{ minHeight: 340 }}>
                <span className="idx">{a.category} · {a.readingMinutes} min</span>
                <h2 style={{ fontSize: 'clamp(1.35rem, 2vw, 1.7rem)', marginTop: 18, lineHeight: 1.12 }}>{a.title}</h2>
                <p>{a.description}</p>
                <span className="more"><time dateTime={a.published}>{fmt(a.published)}</time>&nbsp;· Lire <Arrow /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
