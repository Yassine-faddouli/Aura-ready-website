import Link from 'next/link';
import { notFound } from 'next/navigation';
import { pageMeta, orgId, founderId } from '@/lib/seo';
import { absUrl, site } from '@/lib/site';
import { articles, getArticle, type Block } from '@/content/articles';
import { getService } from '@/content/services';
import { Arrow, Breadcrumbs, CtaBand, FaqList, Inline } from '@/components/ui';
import { JsonLd } from '@/components/JsonLd';

export const dynamicParams = false;
export function generateStaticParams() { return articles.map((a) => ({ slug: a.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const a = getArticle((await params).slug);
  if (!a) return {};
  const m = pageMeta({ title: a.metaTitle, description: a.description, path: `/insights/${a.slug}/`, type: 'article' });
  return { ...m, openGraph: { ...m.openGraph, type: 'article', publishedTime: a.published, modifiedTime: a.updated, authors: [site.founder.name] } };
}

const fmt = (d: string) => new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

function RenderBlock({ b }: { b: Block }) {
  if ('p' in b) return <p><Inline text={b.p} /></p>;
  if ('h3' in b) return <h3>{b.h3}</h3>;
  if ('ul' in b) return <ul>{b.ul.map((x) => <li key={x}><Inline text={x} /></li>)}</ul>;
  if ('ol' in b) return <ol>{b.ol.map((x) => <li key={x}><Inline text={x} /></li>)}</ol>;
  if ('note' in b) return <p className="note"><Inline text={b.note} /></p>;
  return (
    <div className="table-wrap"><table><thead><tr>{b.table.head.map((h) => <th key={h} scope="col">{h}</th>)}</tr></thead>
      <tbody>{b.table.rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}><Inline text={c} /></td>)}</tr>)}</tbody></table></div>
  );
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const a = getArticle((await params).slug);
  if (!a) notFound();
  const path = `/insights/${a.slug}/`;
  const related = a.related.map(getArticle).filter(Boolean) as typeof articles;
  const schema = {
    '@context': 'https://schema.org', '@type': 'Article', headline: a.title, description: a.description,
    datePublished: a.published, dateModified: a.updated, inLanguage: 'fr-MA', mainEntityOfPage: absUrl(path),
    image: absUrl('/og.png'), author: { '@type': 'Person', '@id': founderId, name: site.founder.name, url: absUrl('/about/#founder') },
    publisher: { '@id': orgId },
  };
  return (
    <>
      <JsonLd data={schema} />
      <article>
        <header className="page-hero">
          <div className="container">
            <Breadcrumbs items={[{ name: 'Ressources', path: '/insights/' }, { name: a.title, path }]} />
            <p className="eyebrow">{a.category}</p>
            <h1 style={{ maxWidth: '20ch' }}>{a.title}</h1>
            <div className="meta-line">
              <span>Par <Link className="link" href="/about/#founder">{site.founder.name}</Link></span>
              <span>Publié le <time dateTime={a.published}>{fmt(a.published)}</time></span>
              {a.updated !== a.published ? <span>Mis à jour le <time dateTime={a.updated}>{fmt(a.updated)}</time></span> : null}
              <span>{a.readingMinutes} min de lecture</span>
            </div>
          </div>
        </header>
        <section className="section light">
          <div className="container article-layout">
            <nav className="toc" aria-label="Sommaire">
              <p className="col-title">Sommaire</p>
              <ol>{a.sections.map((s) => <li key={s.id}><a href={`#${s.id}`}>{s.title}</a></li>)}{a.faqs ? <li><a href="#faq">Questions fréquentes</a></li> : null}</ol>
            </nav>
            <div className="prose">
              {a.intro.map((p) => <p key={p} style={{ fontSize: '1.15rem' }}><Inline text={p} /></p>)}
              {a.sections.map((s) => (
                <section key={s.id} aria-labelledby={s.id}>
                  <h2 id={s.id}>{s.title}</h2>
                  {s.blocks.map((b, i) => <RenderBlock key={i} b={b} />)}
                </section>
              ))}
              {a.faqs ? (
                <section aria-labelledby="faq"><h2 id="faq">Questions fréquentes</h2><FaqList faqs={a.faqs} /></section>
              ) : null}
              <p style={{ marginTop: 48 }} className="muted">Services liés : {a.services.map((sl, i) => { const s = getService(sl)!; return <span key={sl}>{i ? ', ' : ''}<Link href={`/services/${sl}/`}>{s.name}</Link></span>; })}</p>
            </div>
          </div>
        </section>
      </article>
      <section className="section">
        <div className="container">
          <div className="section-head"><div><p className="eyebrow">À lire aussi</p><h2>Articles liés</h2></div></div>
          <div className="grid g2">
            {related.map((r) => <Link key={r.slug} href={`/insights/${r.slug}/`} className="card"><span className="idx">{r.category}</span><h3>{r.title}</h3><p>{r.description}</p><span className="more">Lire <Arrow /></span></Link>)}
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
