import { pageMeta } from '@/lib/seo';
import { site } from '@/lib/site';
import { PageHero } from '@/components/ui';

export const metadata = pageMeta({ title: 'Mentions légales', description: 'Mentions légales du site auraacquisition.ma.', path: '/legal-notice/' });
const P = ({ children }: { children: React.ReactNode }) => <span className="placeholder">{children}</span>;

export default function LegalNotice() {
  return (
    <>
      <PageHero crumbs={[{ name: 'Mentions légales', path: '/legal-notice/' }]} title="Mentions légales" />
      <section className="section light">
        <div className="container prose">
          <p className="muted">Les éléments surlignés sont à compléter avec les informations officielles avant la mise en ligne.</p>
          <h2>Éditeur du site</h2>
          <p>{site.name}<br />Statut : {site.legalForm}<br />Responsable de la publication : {site.founder.name}<br />Adresse : <P>[Adresse professionnelle]</P>, {site.city}, Maroc<br />Identifiant Commun de l’Entreprise (ICE) : <P>[ICE]</P><br />Identifiant fiscal (IF) : <P>[IF]</P><br />Numéro auto-entrepreneur : <P>[N° d’inscription au registre national de l’auto-entrepreneur]</P><br />Contact : WhatsApp {site.whatsappDisplay}{site.email ? ` — ${site.email}` : ''}</p>
          <h2>Hébergement</h2>
          <p><P>[Nom de l’hébergeur, adresse et site web — ex. Vercel Inc., 440 N Barranca Ave #4133, Covina, CA 91723, États-Unis]</P></p>
          <h2>Propriété intellectuelle</h2>
          <p>L’ensemble des contenus de ce site (textes, logo, éléments graphiques, vidéos) est la propriété d’{site.name} ou de ses clients, et ne peut être reproduit sans autorisation écrite préalable. Les vidéos présentées dans la section Résultats ont été réalisées pour des clients et sont diffusées avec leur accord.</p>
          <h2>Responsabilité</h2>
          <p>Les informations publiées sur ce site sont fournies à titre indicatif. Les exemples chiffrés présentés dans les articles sont illustratifs et ne constituent pas une promesse de résultat.</p>
          <h2>Données personnelles</h2>
          <p>Voir notre <a href="/privacy-policy/">politique de confidentialité</a>.</p>
        </div>
      </section>
    </>
  );
}
