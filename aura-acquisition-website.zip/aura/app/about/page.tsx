import Link from 'next/link';
import { pageMeta } from '@/lib/seo';
import { site } from '@/lib/site';
import { CtaBand, PageHero, SectionHead } from '@/components/ui';

export const metadata = pageMeta({
  title: 'À propos — une agence orientée acquisition',
  description: "Aura Acquisition est une agence d'acquisition client fondée à Casablanca par Yassine Faddouli. Notre philosophie : des clients qualifiés plutôt que des métriques de vanité.",
  path: '/about/',
});

const principles = [
  { title: 'L’acquisition avant la visibilité', text: 'Les likes, les vues et les abonnés sont des moyens. Nous mesurons ce qui paie vos charges : rendez-vous, inscriptions, clients.' },
  { title: 'La qualité avant le volume', text: 'Nous préférons 40 leads qualifiés à 300 contacts sans intention. C’est meilleur pour votre équipe, votre budget et votre image.' },
  { title: 'La transparence', text: 'Vos campagnes tournent dans vos comptes. Vous voyez les mêmes chiffres que nous, chaque semaine, sans jargon.' },
  { title: 'L’honnêteté', text: 'Pas de résultats garantis, pas de chiffres inventés, pas de faux témoignages. Si nous ne sommes pas la bonne solution, nous vous le disons.' },
];

export default function AboutPage() {
  return (
    <>
      <PageHero crumbs={[{ name: 'À propos', path: '/about/' }]} eyebrow="À propos" title="Une agence construite autour d’un seul résultat : des clients qualifiés."
        lead={`Aura Acquisition est une agence d’acquisition client basée à ${site.city}. Nous aidons les entreprises de la formation et de l’expertise au Maroc à construire un système prévisible pour attirer, qualifier et convertir leurs prospects.`} />

      <section className="section">
        <div className="container two-col">
          <div><p className="eyebrow">Mission</p><h2>Rendre l’acquisition client prévisible.</h2></div>
          <div>
            <p className="lead" style={{ color: 'inherit' }}>Beaucoup d’entreprises marocaines ont une excellente offre mais une acquisition qui dépend du bouche-à-oreille, de la saison ou de la chance. Notre mission est de remplacer cette incertitude par un système&nbsp;: un message clair, des publicités ciblées, une qualification rigoureuse et un suivi organisé.</p>
            <p className="muted">Notre promesse tient en une phrase&nbsp;: <em>« We turn content &amp; ads into qualified clients. »</em> Nous transformons vos contenus et vos publicités en clients qualifiés.</p>
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <SectionHead eyebrow="Philosophie" title="Ce en quoi nous croyons" split={false} />
          <div className="grid g4">
            {principles.map((p, i) => <div key={p.title} className="card"><span className="idx">0{i + 1}</span><h3>{p.title}</h3><p>{p.text}</p></div>)}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container two-col">
          <div><p className="eyebrow">Méthode</p><h2>Le Qualified Pipeline System</h2></div>
          <div>
            <p>Notre méthode relie cinq étapes qui, dans la plupart des entreprises, sont gérées séparément ou pas du tout&nbsp;: le diagnostic de l’offre, la production de contenu, les campagnes Meta Ads, la qualification des prospects et le suivi commercial.</p>
            <p>En les pilotant ensemble, nous pouvons optimiser sur ce qui compte vraiment&nbsp;: le coût par rendez-vous et par client, plutôt que le coût par clic.</p>
            <p><Link className="link" href="/services/">Découvrir nos services →</Link></p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container two-col">
          <div><p className="eyebrow">Façon de travailler</p><h2>Avec nos clients</h2></div>
          <ul className="ticks check">
            <li>Un nombre limité de clients à la fois, pour garder un suivi de qualité</li>
            <li>Un appel stratégique avant tout engagement, pour vérifier que nous pouvons aider</li>
            <li>Vos comptes publicitaires, vos données, vos outils : vous restez propriétaire</li>
            <li>Un point hebdomadaire avec des chiffres clairs et les prochaines actions</li>
            <li>Une communication directe en français, en darija ou en anglais</li>
          </ul>
        </div>
      </section>

      <section className="section light">
        <div className="container two-col">
          <div><p className="eyebrow">Pour qui</p><h2>Les entreprises que nous servons le mieux</h2></div>
          <div>
            <p>Centres de formation, centres et écoles de langues, coachs, consultants et créateurs de formations&nbsp;: des entreprises qui vendent une transformation, dont les clients ont besoin de confiance avant d’acheter et dont la vente passe par une conversation.</p>
            <p><Link className="link" href="/industries/">Voir les secteurs →</Link></p>
          </div>
        </div>
      </section>

      <section className="section" id="founder">
        <div className="container two-col">
          <div><p className="eyebrow">Fondateur</p><h2>{site.founder.name}</h2></div>
          <div>
            <p>{site.founder.name} a fondé Aura Acquisition à {site.city} pour aider les entreprises de l’éducation et de l’expertise à structurer leur acquisition client. Il pilote la stratégie, les campagnes et les systèmes de suivi de chaque client.</p>
            {/* TODO: add a verified short bio (background, experience) and a professional photo. Do not invent credentials. */}
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
