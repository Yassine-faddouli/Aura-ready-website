import { pageMeta } from '@/lib/seo';
import { PageHero } from '@/components/ui';
import { QualificationForm } from '@/components/Forms';

export const metadata = pageMeta({
  title: 'Réserver un appel stratégique — travailler avec nous',
  description: 'Répondez à quelques questions sur votre activité et votre acquisition. Si votre projet correspond à notre expertise, nous organisons un appel stratégique avec Aura Acquisition.',
  path: '/work-with-us/',
});

const steps = [
  { title: 'Vous répondez au formulaire', text: 'Environ 3 minutes. Ces informations nous permettent de préparer l’appel sérieusement.' },
  { title: 'Nous étudions votre demande', text: 'Sous 1 à 2 jours ouvrés. Si nous ne pouvons pas vous aider, nous vous le disons et, si possible, nous vous orientons.' },
  { title: 'Appel stratégique', text: 'Environ 30 minutes : votre acquisition actuelle, les blocages, ce qu’il faudrait changer et si une collaboration a du sens.' },
  { title: 'Proposition', text: 'Si nous avançons, vous recevez une proposition écrite : périmètre, livrables, calendrier et honoraires.' },
];

export default function WorkWithUsPage() {
  return (
    <>
      <PageHero crumbs={[{ name: 'Travailler avec nous', path: '/work-with-us/' }]} eyebrow="Appel stratégique" title="Voyons si nous pouvons vous aider."
        lead="Nous travaillons avec un nombre limité d’entreprises à la fois. Ce formulaire nous aide à comprendre votre situation et à vérifier, avant l’appel, que nous sommes la bonne équipe pour vous." />
      <section className="section">
        <div className="container two-col wide-left">
          <QualificationForm />
          <div>
            <p className="col-title">Ce qui se passe ensuite</p>
            <ol className="steps">{steps.map((s) => <li key={s.title} style={{ gridTemplateColumns: '48px 1fr' }}><div><h3 style={{ marginBottom: 8, fontSize: '1.15rem' }}>{s.title}</h3><p>{s.text}</p></div></li>)}</ol>
            <p className="muted" style={{ marginTop: 28, fontSize: '0.92rem' }}>L’appel stratégique est un échange de diagnostic, pas une présentation commerciale déguisée. Aucun engagement.</p>
          </div>
        </div>
      </section>
    </>
  );
}
