import { pageMeta } from '@/lib/seo';
import { site } from '@/lib/site';
import { PageHero } from '@/components/ui';

export const metadata = pageMeta({ title: 'Politique cookies', description: 'Utilisation des cookies sur le site d’Aura Acquisition.', path: '/cookie-policy/' });

export default function Cookies() {
  return (
    <>
      <PageHero crumbs={[{ name: 'Politique cookies', path: '/cookie-policy/' }]} title="Politique cookies" />
      <section className="section light">
        <div className="container prose">
          {site.gaId ? (
            <>
              <p>Ce site utilise Google Analytics 4 pour mesurer son audience (pages visitées, durée, provenance). Ces cookies ne sont déposés <strong>qu’après votre accord</strong>, via le bandeau affiché lors de votre première visite. Vous pouvez refuser sans conséquence sur votre navigation.</p>
              <p>Pour modifier votre choix, effacez les données de ce site dans votre navigateur : le bandeau s’affichera à nouveau.</p>
            </>
          ) : (
            <p>Ce site ne dépose actuellement <strong>aucun cookie</strong> de mesure d’audience, de publicité ou de suivi. Si des outils de mesure sont ajoutés, ils ne seront activés qu’après votre consentement explicite et cette page sera mise à jour.</p>
          )}
          <p>Les vidéos du site sont hébergées directement sur notre serveur et ne déposent pas de cookies tiers.</p>
        </div>
      </section>
    </>
  );
}
