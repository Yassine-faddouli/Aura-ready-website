import Link from 'next/link';
import { notFound } from 'next/navigation';
import { pageMeta, serviceSchema } from '@/lib/seo';
import { services, getService } from '@/content/services';
import { industries } from '@/content/industries';
import { Arrow, CtaBand, CtaButtons, FaqList, PageHero } from '@/components/ui';
import { JsonLd } from '@/components/JsonLd';

export const dynamicParams = false;
export function generateStaticParams() { return services.map((s) => ({ slug: s.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const s = getService((await params).slug);
  if (!s) return {};
  return pageMeta({ title: s.metaTitle, description: s.metaDescription, path: `/services/${s.slug}/` });
}

export default async function ServicePage({ params }: { params: Promise<{ slug: string }> }) {
  const s = getService((await params).slug);
  if (!s) notFound();
  const path = `/services/${s.slug}/`;
  const related = s.related.map(getService).filter(Boolean) as typeof services;
  const relInd = industries.filter((i) => i.services.includes(s.slug));
  return (
    <>
      <JsonLd data={serviceSchema({ name: s.name, description: s.metaDescription, path, serviceType: s.serviceType })} />
      <PageHero crumbs={[{ name: 'Services', path: '/services/' }, { name: s.name, path }]} eyebrow={s.name} title={s.h1} lead={s.intro}>
        <CtaButtons secondary={{ href: '#processus', label: 'Voir le processus' }} />
      </PageHero>

      <section className="section">
        <div className="container two-col">
          <div>
            <p className="col-title">Le problème</p>
            <h2 style={{ fontSize: 'clamp(1.7rem, 3vw, 2.5rem)', marginBottom: 28 }}>{s.problemTitle}</h2>
            <ul className="ticks cross">{s.problem.map((p) => <li key={p}>{p}</li>)}</ul>
          </div>
          <div>
            <p className="col-title">Pour qui</p>
            <h2 style={{ fontSize: 'clamp(1.7rem, 3vw, 2.5rem)', marginBottom: 28 }}>À qui s’adresse ce service</h2>
            <ul className="ticks check">{s.forWho.map((p) => <li key={p}>{p}</li>)}</ul>
          </div>
        </div>
      </section>

      <section className="section light" id="processus">
        <div className="container">
          <div className="section-head"><div><p className="eyebrow">Processus</p><h2>Comment nous travaillons</h2></div></div>
          <ol className="steps">{s.process.map((st) => <li key={st.title}><h3>{st.title}</h3><p>{st.text}</p></li>)}</ol>
        </div>
      </section>

      <section className="section">
        <div className="container two-col">
          <div>
            <p className="eyebrow">Livrables</p>
            <h2>Ce que vous recevez</h2>
            <p className="lead" style={{ marginTop: 20 }}>Des éléments concrets, documentés et réutilisables par votre équipe, dans vos propres comptes et outils.</p>
          </div>
          <ul className="ticks check">{s.deliverables.map((d) => <li key={d}>{d}</li>)}</ul>
        </div>
      </section>

      <section className="section">
        <div className="container two-col sticky-left">
          <div><p className="eyebrow">Questions fréquentes</p><h2>{s.name} : vos questions</h2></div>
          <FaqList faqs={s.faqs} />
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <div className="section-head"><div><p className="eyebrow">À combiner avec</p><h2>Services complémentaires</h2></div></div>
          <div className="grid g3">
            {related.map((r) => (
              <Link key={r.slug} href={`/services/${r.slug}/`} className="card"><h3 style={{ marginTop: 0 }}>{r.name}</h3><p>{r.short}</p><span className="more">Voir <Arrow /></span></Link>
            ))}
          </div>
          {relInd.length ? (
            <p style={{ marginTop: 32 }} className="muted">Particulièrement utile pour : {relInd.map((i, k) => <span key={i.slug}>{k ? ', ' : ''}<Link className="link" href={`/industries/${i.slug}/`}>{i.name.toLowerCase()}</Link></span>)}.</p>
          ) : null}
        </div>
      </section>
      <CtaBand title={`Parlons de votre ${s.name.toLowerCase().startsWith('crm') ? 'suivi des leads' : 'acquisition'}.`} />
    </>
  );
}
