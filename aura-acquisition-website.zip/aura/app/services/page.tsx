import Link from 'next/link';
import { pageMeta } from '@/lib/seo';
import { services } from '@/content/services';
import { Arrow, CtaBand, PageHero, SectionHead } from '@/components/ui';

export const metadata = pageMeta({
  title: 'Services d’acquisition client : Meta Ads, funnels, CRM',
  description: 'Génération de leads, Meta Ads, funnels de conversion, qualification, CRM et automatisation WhatsApp, conversion commerciale : les services d’Aura Acquisition au Maroc.',
  path: '/services/',
});

export default function ServicesPage() {
  return (
    <>
      <PageHero crumbs={[{ name: 'Services', path: '/services/' }]} eyebrow="Services" title="Un système d’acquisition, service par service."
        lead="Attirer, qualifier, suivre, convertir. Chaque service traite une étape précise du parcours entre un inconnu et un client. Ensemble, ils forment un pipeline mesurable." />
      <section className="section">
        <div className="container">
          <div className="grid g2">
            {services.map((s, i) => (
              <Link key={s.slug} href={`/services/${s.slug}/`} className="card" style={{ minHeight: 280 }}>
                <span className="idx">0{i + 1}</span>
                <h2 style={{ fontSize: 'clamp(1.6rem, 2.6vw, 2.2rem)', marginTop: 18 }}>{s.name}</h2>
                <p>{s.short}</p>
                <span className="more">Voir le service <Arrow /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section className="section light">
        <div className="container">
          <SectionHead eyebrow="Comment choisir" title="Par où commencer ?" split={false} />
          <div className="two-col">
            <ul className="ticks">
              <li><strong>Vous n’avez pas ou peu de leads</strong> → <Link className="link" href="/services/lead-generation/">Génération de leads</Link> et <Link className="link" href="/services/meta-ads/">Meta Ads</Link></li>
              <li><strong>Vous avez des leads mais peu sérieux</strong> → <Link className="link" href="/services/lead-qualification/">Qualification des leads</Link></li>
              <li><strong>Les prospects se perdent entre la pub et le rendez-vous</strong> → <Link className="link" href="/services/conversion-funnels/">Funnels de conversion</Link></li>
            </ul>
            <ul className="ticks">
              <li><strong>Les relances ne sont pas faites</strong> → <Link className="link" href="/services/crm-whatsapp-automation/">CRM & automatisation WhatsApp</Link></li>
              <li><strong>Des rendez-vous, mais peu de clients</strong> → <Link className="link" href="/services/sales-conversion/">Conversion commerciale</Link></li>
              <li><strong>Vous ne savez pas où est le blocage</strong> → <Link className="link" href="/work-with-us/">Réservez un appel stratégique</Link></li>
            </ul>
          </div>
        </div>
      </section>
      <CtaBand secondary={{ href: '/industries/', label: 'Voir les secteurs' }} />
    </>
  );
}
