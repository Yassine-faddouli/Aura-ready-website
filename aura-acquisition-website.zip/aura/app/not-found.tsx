import Link from 'next/link';
import type { Metadata } from 'next';
import { CtaButtons } from '@/components/ui';

export const metadata: Metadata = { title: 'Page introuvable', robots: { index: false, follow: true } };

export default function NotFound() {
  return (
    <section className="not-found">
      <div className="container">
        <p className="eyebrow">Erreur 404</p>
        <h1 style={{ maxWidth: '14ch', marginBottom: 28 }}>Cette page n’existe pas ou a été déplacée.</h1>
        <p className="lead" style={{ marginBottom: 36 }}>Retournez à l’<Link className="link" href="/">accueil</Link>, consultez nos services ou réservez directement un appel stratégique.</p>
        <CtaButtons />
      </div>
    </section>
  );
}
