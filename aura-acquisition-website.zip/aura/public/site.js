/* Aura Acquisition — progressive enhancement (menu, reveal, forms, optional analytics consent). No dependencies. */
(function () {
  'use strict';
  var d = document;

  // Mobile menu
  var btn = d.querySelector('[data-menu-toggle]');
  var menu = d.getElementById('mobile-nav');
  if (btn && menu) btn.addEventListener('click', function () {
    var open = menu.classList.toggle('open');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  // Current page in nav
  var here = location.pathname.replace(/index\.html$/, '');
  d.querySelectorAll('[data-nav]').forEach(function (a) {
    var href = a.getAttribute('href');
    if (href && href !== '/' && here.indexOf(href) === 0) a.setAttribute('aria-current', 'page');
  });

  // Reveal on scroll
  var els = d.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -8% 0px' });
    els.forEach(function (el) { io.observe(el); });
  } else els.forEach(function (el) { el.classList.add('in'); });

  // Forms
  var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  function setError(form, field, msg) {
    var name = field.name;
    var err = form.querySelector('#' + name + '-error');
    if (field.type !== 'radio') field.setAttribute('aria-invalid', msg ? 'true' : 'false');
    if (err) err.textContent = msg || '';
  }
  function validate(form) {
    var first = null; var seen = {};
    form.querySelectorAll('input, select, textarea').forEach(function (f) {
      if (!f.name || f.closest('.hp') || seen[f.name]) return;
      var msg = '';
      var v = (f.value || '').trim();
      if (f.type === 'radio') {
        seen[f.name] = true;
        var group = form.querySelectorAll('input[name="' + f.name + '"]');
        var req = Array.prototype.some.call(group, function (r) { return r.required; });
        var any = Array.prototype.some.call(group, function (r) { return r.checked; });
        if (req && !any) msg = 'Veuillez choisir une option.';
      } else if (f.type === 'checkbox') {
        if (f.required && !f.checked) msg = 'Votre accord est nécessaire pour traiter la demande.';
      } else if (f.required && !v) msg = 'Ce champ est obligatoire.';
      else if (f.type === 'email' && v && !EMAIL.test(v)) msg = 'Adresse e-mail invalide.';
      else if (f.type === 'tel' && v && v.replace(/[^\d]/g, '').length < 8) msg = 'Numéro de téléphone invalide.';
      setError(form, f, msg);
      if (msg && !first) first = f;
    });
    if (first) first.focus();
    return !first;
  }
  function collect(form) {
    var data = {}; var fd = new FormData(form);
    fd.forEach(function (v, k) { if (k !== 'company_url' && k !== 'consent') data[k] = String(v).trim(); });
    data.form = form.getAttribute('data-aura-form');
    data.page = location.href;
    data.submittedAt = new Date().toISOString();
    return data;
  }
  function waMessage(form, data) {
    var lines = [data.form === 'qualification' ? 'Bonjour Aura Acquisition, voici ma demande d’appel stratégique :' : 'Bonjour Aura Acquisition,'];
    form.querySelectorAll('[data-label]').forEach(function (f) {
      if (f.type === 'checkbox' || (f.type === 'radio' && !f.checked)) return;
      if (data[f.name]) lines.push('• ' + f.getAttribute('data-label') + ' : ' + data[f.name]);
    });
    return lines.join('\n');
  }
  function show(form, title, text, actions) {
    var box = form.parentNode.querySelector('[data-status]');
    box.querySelector('[data-status-title]').textContent = title;
    box.querySelector('[data-status-text]').textContent = text;
    var act = box.querySelector('[data-status-actions]'); act.innerHTML = '';
    (actions || []).forEach(function (a) {
      var el = d.createElement('a'); el.className = 'btn' + (a.ghost ? ' btn-ghost' : ''); el.href = a.href; el.textContent = a.label;
      if (a.external) { el.target = '_blank'; el.rel = 'noopener'; }
      act.appendChild(el);
    });
    box.classList.add('show'); box.focus();
  }
  d.querySelectorAll('[data-aura-form]').forEach(function (form) {
    form.addEventListener('input', function (e) { if (e.target.getAttribute('aria-invalid') === 'true') setError(form, e.target, ''); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (form.querySelector('[name="company_url"]').value) return; // bot
      if (!validate(form)) return;
      var data = collect(form);
      var endpoint = form.getAttribute('data-endpoint');
      var wa = 'https://wa.me/' + form.getAttribute('data-whatsapp') + '?text=' + encodeURIComponent(waMessage(form, data));
      var booking = form.getAttribute('data-booking');
      var submit = form.querySelector('[type="submit"]');
      if (!endpoint) {
        // No backend configured: be honest — nothing has been sent yet.
        form.style.display = 'none';
        show(form, 'Dernière étape : envoyez votre demande',
          'Vos réponses sont prêtes. Cliquez sur le bouton ci-dessous pour les envoyer sur WhatsApp : votre demande ne nous parvient qu’à ce moment-là.',
          [{ label: 'Envoyer sur WhatsApp', href: wa, external: true }]);
        return;
      }
      submit.disabled = true; submit.textContent = 'Envoi…';
      fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(data) })
        .then(function (r) { if (!r.ok) throw new Error(r.status); })
        .then(function () {
          form.style.display = 'none';
          var actions = booking ? [{ label: 'Choisir un créneau', href: booking, external: true }] : [];
          show(form, 'Demande bien reçue',
            data.form === 'qualification'
              ? 'Merci. Nous étudions votre demande et revenons vers vous sous 1 à 2 jours ouvrés par le moyen de contact choisi. Si votre projet ne correspond pas à notre expertise, nous vous le dirons honnêtement.'
              : 'Merci pour votre message. Nous vous répondons sous 1 à 2 jours ouvrés.',
            actions);
        })
        .catch(function () {
          submit.disabled = false; submit.textContent = 'Réessayer';
          show(form, 'L’envoi a échoué', 'Votre demande n’a pas pu être transmise. Réessayez ou envoyez-la directement sur WhatsApp.', [{ label: 'Envoyer sur WhatsApp', href: wa, external: true }]);
        });
    });
  });

  // Optional analytics — loaded ONLY after explicit consent, and only if a GA ID is configured.
  var ga = d.documentElement.getAttribute('data-ga');
  if (ga) {
    var KEY = 'aura-consent';
    var load = function () {
      var s = d.createElement('script'); s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + ga; d.head.appendChild(s);
      window.dataLayer = window.dataLayer || []; window.gtag = function () { dataLayer.push(arguments); };
      gtag('js', new Date()); gtag('config', ga, { anonymize_ip: true });
    };
    var saved = null; try { saved = localStorage.getItem(KEY); } catch (e) {}
    if (saved === 'yes') load();
    else if (saved !== 'no') {
      var bar = d.querySelector('[data-cookie]');
      if (bar) {
        bar.classList.add('show');
        bar.querySelector('[data-accept]').addEventListener('click', function () { try { localStorage.setItem(KEY, 'yes'); } catch (e) {} bar.classList.remove('show'); load(); });
        bar.querySelector('[data-decline]').addEventListener('click', function () { try { localStorage.setItem(KEY, 'no'); } catch (e) {} bar.classList.remove('show'); });
      }
    }
  }
})();
