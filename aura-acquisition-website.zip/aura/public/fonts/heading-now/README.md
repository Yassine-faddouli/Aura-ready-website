# Heading Now — font files go here

Add the licensed WOFF2 files with exactly these names (only the weights you own are required):

- HeadingNow-Regular.woff2 (400)
- HeadingNow-Medium.woff2  (500)
- HeadingNow-Bold.woff2    (700)  ← used by all headings
- HeadingNow-Black.woff2   (900)

Then run `npm run build`. The @font-face rules and preload are generated automatically (see lib/fonts.ts).
If you only have OTF/TTF, convert them to WOFF2 (e.g. `pip install fonttools brotli` then
`pyftsubset HeadingNow-Bold.otf --flavor=woff2 --output-file=HeadingNow-Bold.woff2 --unicodes="*"`), checking that your licence allows web embedding.
