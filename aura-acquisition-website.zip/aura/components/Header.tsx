import Link from 'next/link';
import { nav, cta, site } from '@/lib/site';
import { LogoMark } from './Logo';

export function Header() {
  return (
    <header className="header">
      <div className="container header-inner">
        <Link href="/" className="brand" aria-label={`${site.name} — accueil`}>
          <LogoMark />
          <span>Aura Acquisition</span>
        </Link>
        <nav className="nav" aria-label="Navigation principale">
          <ul>{nav.map((n) => <li key={n.href}><Link href={n.href} data-nav>{n.label}</Link></li>)}</ul>
        </nav>
        <Link href={cta.primary.href} className="btn btn-sm header-cta">{cta.primary.label}</Link>
        <button className="menu-btn" type="button" aria-expanded="false" aria-controls="mobile-nav" data-menu-toggle>
          <span aria-hidden="true" />Menu
        </button>
      </div>
      <nav id="mobile-nav" className="mobile-nav" aria-label="Navigation mobile">
        <ul>
          {nav.map((n) => <li key={n.href}><Link href={n.href}>{n.label}</Link></li>)}
        </ul>
        <Link href={cta.primary.href} className="btn" style={{ width: '100%' }}>{cta.primary.label}</Link>
      </nav>
    </header>
  );
}
