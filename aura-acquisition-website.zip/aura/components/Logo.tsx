export function LogoMark({ className, title }: { className?: string; title?: string }) {
  return (
    <svg className={className} viewBox="270 265 501 495" fill="currentColor" aria-hidden={title ? undefined : true} role={title ? 'img' : undefined}>
      {title ? <title>{title}</title> : null}
      <path d="M520 270 L766 755 L535 603 L607 603 L520 430 L432 603 L505 603 L275 755 Z" />
    </svg>
  );
}
