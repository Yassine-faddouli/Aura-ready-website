import Link from 'next/link';
import { site, waLink } from '@/lib/site';
import { services } from '@/content/services';
import { industries } from '@/content/industries';
import { LogoMark } from './Logo';

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-top">
          <div>
            <Link href="/" className="brand" aria-label={`${site.name} — accueil`}><LogoMark /><span>Aura Acquisition</span></Link>
            <p className="tagline">Attract.<br />Convert.<br />Scale.</p>
            <p className="muted" style={{ maxWidth: '34ch', fontSize: '0.93rem' }}>Agence d’acquisition client à {site.city}. Meta Ads, funnels, qualification et suivi WhatsApp pour les entreprises de l’éducation et de l’expertise au Maroc.</p>
          </div>
          <div>
            <h2>Services</h2>
            <ul>{services.map((s) => <li key={s.slug}><Link href={`/services/${s.slug}/`}>{s.name}</Link></li>)}</ul>
          </div>
          <div>
            <h2>Secteurs</h2>
            <ul>{industries.map((i) => <li key={i.slug}><Link href={`/industries/${i.slug}/`}>{i.name}</Link></li>)}</ul>
          </div>
          <div>
            <h2>Agence</h2>
            <ul>
              <li><Link href="/about/">À propos</Link></li>
              <li><Link href="/results/">Résultats</Link></li>
              <li><Link href="/insights/">Ressources</Link></li>
              <li><Link href="/work-with-us/">Travailler avec nous</Link></li>
            </ul>
          </div>
          <div>
            <h2>Contact</h2>
            <ul>
              <li><a href={waLink('Bonjour Aura Acquisition, je souhaite parler de mon acquisition client.')} target="_blank" rel="noopener">WhatsApp</a></li>
              {site.email ? <li><a href={`mailto:${site.email}`}>{site.email}</a></li> : null}
              <li><Link href="/contact/">Formulaire de contact</Link></li>
              <li><span className="muted" style={{ fontSize: '0.93rem' }}>{site.city}, {site.country}</span></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <div>© {year} {site.name}. Tous droits réservés.</div>
          <div>
            <Link href="/legal-notice/">Mentions légales</Link>
            <Link href="/privacy-policy/">Confidentialité</Link>
            <Link href="/cookie-policy/">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
