import Link from 'next/link';
import { site } from '@/lib/site';

const industries = ['Centre de formation', 'Centre / école de langues', 'Coach ou consultant', 'Créateur de formations / éducation en ligne', 'Autre'];
const challenges = ['Pas assez de leads', 'Des leads mais peu qualifiés', 'Des leads mais peu de clients (suivi / vente)', 'Résultats irréguliers d’un mois à l’autre', 'Je ne sais pas mesurer ce qui fonctionne', 'Autre'];
const methods = ['Bouche-à-oreille / recommandations', 'Publications organiques (Instagram, Facebook, TikTok)', 'Publicités Meta gérées en interne', 'Publicités gérées par une agence ou un freelance', 'Google / site web', 'Aucune méthode structurée'];
const budgets = ['Moins de 3 000 MAD / mois', '3 000 – 7 000 MAD / mois', '7 000 – 15 000 MAD / mois', '15 000 – 30 000 MAD / mois', 'Plus de 30 000 MAD / mois', 'Je ne sais pas encore'];
const contactPrefs = ['WhatsApp', 'Appel téléphonique', 'E-mail'];

function Consent() {
  return (
    <div className="field">
      <label className="consent">
        <input type="checkbox" name="consent" required data-label="Consentement" />
        <span>J’accepte qu’Aura Acquisition utilise ces informations pour me recontacter au sujet de ma demande. Voir la <Link href="/privacy-policy/" className="link">politique de confidentialité</Link>.</span>
      </label>
      <span className="error" id="consent-error" />
    </div>
  );
}

function Status() {
  return (
    <div className="form-status" role="status" aria-live="polite" tabIndex={-1} data-status>
      <h3 data-status-title />
      <p data-status-text />
      <div className="btn-row" data-status-actions />
    </div>
  );
}

function Select({ name, label, options, required = true }: { name: string; label: string; options: string[]; required?: boolean }) {
  return (
    <div className="field">
      <label htmlFor={name}>{label}{required ? null : <span className="opt"> (facultatif)</span>}</label>
      <select id={name} name={name} required={required} defaultValue="" data-label={label} aria-describedby={`${name}-error`}>
        <option value="" disabled>Choisir…</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
      <span className="error" id={`${name}-error`} />
    </div>
  );
}

function Input({ name, label, type = 'text', required = true, autoComplete, placeholder, hint }: { name: string; label: string; type?: string; required?: boolean; autoComplete?: string; placeholder?: string; hint?: string }) {
  return (
    <div className="field">
      <label htmlFor={name}>{label}{required ? null : <span className="opt"> (facultatif)</span>}</label>
      <input id={name} name={name} type={type} required={required} autoComplete={autoComplete} placeholder={placeholder} data-label={label} aria-describedby={`${name}-error${hint ? ` ${name}-hint` : ''}`} />
      {hint ? <span className="hint" id={`${name}-hint`}>{hint}</span> : null}
      <span className="error" id={`${name}-error`} />
    </div>
  );
}

const formAttrs = (kind: string) => ({
  'data-aura-form': kind,
  'data-endpoint': site.formEndpoint,
  'data-booking': site.bookingUrl,
  'data-whatsapp': site.whatsapp,
  noValidate: true,
  method: 'post' as const,
  action: site.formEndpoint || undefined,
});

export function QualificationForm() {
  return (
    <div className="form-panel">
      <form className="form" {...formAttrs('qualification')}>
        <div className="form-row">
          <Input name="name" label="Nom complet" autoComplete="name" />
          <Input name="email" label="E-mail professionnel" type="email" autoComplete="email" />
        </div>
        <div className="form-row">
          <Input name="company" label="Nom de l’entreprise" autoComplete="organization" />
          <Input name="website" label="Site web ou profil social" placeholder="https:// ou @instagram" />
        </div>
        <div className="form-row">
          <Input name="phone" label="Téléphone / WhatsApp" type="tel" autoComplete="tel" placeholder="+212 …" />
          <Select name="industry" label="Secteur" options={industries} />
        </div>
        <Select name="challenge" label="Principal défi d’acquisition" options={challenges} />
        <Select name="method" label="Méthode actuelle de génération de leads" options={methods} />
        <Select name="budget" label="Budget marketing mensuel approximatif (publicité incluse)" options={budgets} />
        <div className="field">
          <label htmlFor="goal">Objectif principal pour les 3 prochains mois</label>
          <textarea id="goal" name="goal" required data-label="Objectif principal" aria-describedby="goal-error" placeholder="Ex. remplir la session de janvier, obtenir 15 appels découverte qualifiés par mois…" />
          <span className="error" id="goal-error" />
        </div>
        <fieldset className="field choices" aria-describedby="contactPref-error">
          <legend>Moyen de contact préféré</legend>
          {contactPrefs.map((c, i) => (
            <label className="choice" key={c}><input type="radio" name="contactPref" value={c} required={i === 0} data-label="Moyen de contact préféré" /><span>{c}</span></label>
          ))}
          <span className="error" id="contactPref-error" style={{ width: '100%' }} />
        </fieldset>
        <div className="hp" aria-hidden="true"><label>Ne pas remplir<input type="text" name="company_url" tabIndex={-1} autoComplete="off" /></label></div>
        <Consent />
        <div><button type="submit" className="btn">Envoyer ma demande <span className="arrow" aria-hidden="true">→</span></button></div>
      </form>
      <Status />
    </div>
  );
}

export function ContactForm() {
  return (
    <div className="form-panel">
      <form className="form" {...formAttrs('contact')}>
        <div className="form-row">
          <Input name="name" label="Nom complet" autoComplete="name" />
          <Input name="email" label="E-mail" type="email" autoComplete="email" />
        </div>
        <div className="form-row">
          <Input name="phone" label="Téléphone / WhatsApp" type="tel" autoComplete="tel" required={false} />
          <Input name="company" label="Entreprise" autoComplete="organization" required={false} />
        </div>
        <div className="field">
          <label htmlFor="message">Votre message</label>
          <textarea id="message" name="message" required data-label="Message" aria-describedby="message-error" />
          <span className="error" id="message-error" />
        </div>
        <div className="hp" aria-hidden="true"><label>Ne pas remplir<input type="text" name="company_url" tabIndex={-1} autoComplete="off" /></label></div>
        <Consent />
        <div><button type="submit" className="btn">Envoyer <span className="arrow" aria-hidden="true">→</span></button></div>
      </form>
      <Status />
    </div>
  );
}
