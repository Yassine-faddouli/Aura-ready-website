import Link from 'next/link';
import type { ReactNode } from 'react';
import { cta } from '@/lib/site';
import { breadcrumbSchema } from '@/lib/seo';
import type { Faq } from '@/content/services';
import type { WorkItem } from '@/content/work';
import { JsonLd } from './JsonLd';
import { LogoMark } from './Logo';

export const Arrow = () => <span className="arrow" aria-hidden="true">→</span>;

export function Breadcrumbs({ items }: { items: { name: string; path: string }[] }) {
  const all = [{ name: 'Accueil', path: '/' }, ...items];
  return (
    <nav className="crumbs" aria-label="Fil d’Ariane">
      <ol>
        {all.map((it, i) => (
          <li key={it.path}>{i === all.length - 1 ? <span aria-current="page">{it.name}</span> : <Link href={it.path}>{it.name}</Link>}</li>
        ))}
      </ol>
      <JsonLd data={breadcrumbSchema(all)} />
    </nav>
  );
}

export function PageHero({ crumbs, eyebrow, title, lead, children }: { crumbs: { name: string; path: string }[]; eyebrow?: string; title: string; lead?: string; children?: ReactNode }) {
  return (
    <section className="page-hero">
      <div className="container">
        <Breadcrumbs items={crumbs} />
        {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
        <h1>{title}</h1>
        {lead ? <p className="lead">{lead}</p> : null}
        {children}
      </div>
    </section>
  );
}

export function CtaButtons({ secondary = cta.secondary }: { secondary?: { href: string; label: string } | null }) {
  return (
    <div className="btn-row">
      <Link href={cta.primary.href} className="btn">{cta.primary.label} <Arrow /></Link>
      {secondary ? <Link href={secondary.href} className="btn btn-ghost">{secondary.label}</Link> : null}
    </div>
  );
}

export function CtaBand({ title = 'Prêt à construire un pipeline de clients qualifiés ?', text = "Répondez à quelques questions sur votre activité. Si nous pouvons vous aider, nous organisons un appel stratégique pour analyser votre acquisition actuelle.", secondary = cta.secondary }: { title?: string; text?: string; secondary?: { href: string; label: string } | null }) {
  return (
    <section className="cta-band">
      <div className="container">
        <h2>{title}</h2>
        <p className="lead">{text}</p>
        <CtaButtons secondary={secondary} />
      </div>
      <LogoMark className="mark" />
    </section>
  );
}

export function FaqList({ faqs }: { faqs: Faq[] }) {
  return (
    <div className="faq">
      {faqs.map((f) => (
        <details key={f.q}>
          <summary>{f.q}</summary>
          <div className="answer"><p>{f.a}</p></div>
        </details>
      ))}
    </div>
  );
}

export function SectionHead({ eyebrow, title, lead, split = true, as: Tag = 'h2' }: { eyebrow?: string; title: string; lead?: string; split?: boolean; as?: 'h2' | 'h3' }) {
  return (
    <div className={`section-head${split && lead ? ' split' : ''}`}>
      <div>{eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}<Tag>{title}</Tag></div>
      {lead ? <p className="lead">{lead}</p> : null}
    </div>
  );
}

export function WorkVideo({ item }: { item: WorkItem }) {
  return (
    <figure className="work">
      <video controls preload="none" playsInline poster={`/work/${item.id}.jpg`} aria-label={`${item.title} — ${item.sector}`}>
        <source src={`/work/${item.id}.mp4`} type="video/mp4" />
      </video>
      <figcaption><strong>{item.title}</strong><span>{item.sector} · {item.format}</span></figcaption>
    </figure>
  );
}

/** Minimal inline formatting: [label](/path/) and **bold** */
export function Inline({ text }: { text: string }) {
  const parts: ReactNode[] = [];
  const re = /\[([^\]]+)\]\(([^)]+)\)|\*\*([^*]+)\*\*/g;
  let last = 0; let m: RegExpExecArray | null; let k = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    if (m[1]) parts.push(m[2].startsWith('/') ? <Link key={k++} href={m[2]}>{m[1]}</Link> : <a key={k++} href={m[2]} rel="noopener">{m[1]}</a>);
    else parts.push(<strong key={k++}>{m[3]}</strong>);
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return <>{parts}</>;
}
