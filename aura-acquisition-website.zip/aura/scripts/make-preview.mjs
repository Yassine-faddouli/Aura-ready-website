// Builds a portable copy of /out in /preview with RELATIVE links and no Next.js runtime,
// so the static site can be opened from any sub-path or file host (used for review links only).
// Production deploys should use /out directly.
import fs from 'node:fs';
import path from 'node:path';

const src = path.resolve('out');
const dst = path.resolve('preview');
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });

function walk(d, acc = []) {
  for (const f of fs.readdirSync(d)) { const p = path.join(d, f); fs.statSync(p).isDirectory() ? walk(p, acc) : acc.push(p); }
  return acc;
}
const toRel = (fromFile, url) => {
  const [p, hash = ''] = url.split('#');
  let target = p;
  if (target.endsWith('/')) target += 'index.html';
  let rel = path.relative(path.dirname(fromFile), path.join(dst, target)).split(path.sep).join('/');
  if (!rel) rel = 'index.html';
  return rel + (hash ? '#' + hash : '');
};

for (const file of walk(dst)) {
  if (file.endsWith('.html')) {
    let h = fs.readFileSync(file, 'utf8');
    h = h.replace(/<script[^>]*src="\/_next\/[^"]*"[^>]*><\/script>/g, '');
    h = h.replace(/<link[^>]*rel="preload"[^>]*as="script"[^>]*\/?>/g, '');
    h = h.replace(/<script>(?:(?!<\/script>)[\s\S])*?self\.__next_f(?:(?!<\/script>)[\s\S])*?<\/script>/g, '');
    h = h.replace(/(href|src|poster|content)="(\/(?!\/)[^"]*)"/g, (m, attr, url) => (attr === 'content' ? m : `${attr}="${toRel(file, url)}"`));
    fs.writeFileSync(file, h);
  } else if (file.endsWith('.css')) {
    let c = fs.readFileSync(file, 'utf8');
    c = c.replace(/url\((\/[^)]+)\)/g, (m, url) => `url(${toRel(file, url)})`);
    fs.writeFileSync(file, c);
  }
}
for (const f of walk(path.join(dst, '_next'))) if (f.endsWith('.js')) fs.rmSync(f);
fs.rmSync(path.join(dst, 'fonts'), { recursive: true, force: true });
// Some static hosts reserve names starting with "_": move /_next to /next-static.
fs.renameSync(path.join(dst, '_next'), path.join(dst, 'next-static'));
for (const f of walk(dst)) if (f.endsWith('.html')) fs.writeFileSync(f, fs.readFileSync(f, 'utf8').replace(/_next\//g, 'next-static/'));
for (const f of walk(dst)) if (f.endsWith('.txt') && !f.endsWith('robots.txt')) fs.rmSync(f);
fs.rmSync(path.join(dst, '404'), { recursive: true, force: true });
console.log('preview ready in', dst);
