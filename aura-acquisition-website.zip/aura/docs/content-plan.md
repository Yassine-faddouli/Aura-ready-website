# Insights content plan (first 6 months)

Published (3): lead vs lead qualifié · relance prospects centre de formation · budget Meta Ads Maroc.

Next articles — one every 2 weeks, each must contain original, practical material (process, template, real example with permission). Skip any topic you cannot write with real expertise.

| # | Working title | Intent | Links to |
|---|---|---|---|
| 4 | Qu'est-ce qu'une agence de génération de leads (et quand en avez-vous besoin) ? | Info → commercial | /services/lead-generation/ |
| 5 | Formulaire instantané Meta ou Click-to-WhatsApp : lequel choisir ? | Info | /services/meta-ads/ |
| 6 | 7 questions à poser dans un formulaire de lead pour un centre de formation | Info | /services/lead-qualification/ |
| 7 | Journée portes ouvertes : comment la promouvoir avec Meta Ads | Info | /industries/training-centers/ |
| 8 | Comment réduire les rendez-vous non honorés (no-show) | Info | /services/conversion-funnels/ |
| 9 | Script WhatsApp : répondre à « c'est combien ? » sans perdre le prospect | Info | /services/sales-conversion/ |
| 10 | CRM simple sur Google Sheets pour une école : modèle et colonnes | Info | /services/crm-whatsapp-automation/ |
| 11 | Publicité pour école de langues : 5 angles par profil (parents, étudiants, pros) | Info | /industries/language-centers/ |
| 12 | Coachs : page de candidature vs appel gratuit | Info | /industries/coaches-consultants/ |
| 13 | Les indicateurs d'acquisition à suivre chaque semaine | Info | /services/lead-generation/ |
| 14 | Étude de cas #1 (only with verified data + permission) | Proof | /results/ |

Each article: add it to `content/articles.ts` (structure is self-documenting), set real `published`/`updated` dates, 2–4 internal links, 1–2 related articles. The sitemap and Article schema update automatically.
