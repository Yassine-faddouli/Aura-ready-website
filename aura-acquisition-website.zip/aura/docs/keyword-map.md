# Keyword map — Aura Acquisition (FR, Morocco)

**Status: hypotheses.** No search-volume tool was used. Volumes and difficulty are unverified.
Validate in Google Search Console after 6–8 weeks of indexing, and optionally with Google Keyword Planner (free with a Google Ads account) or Semrush/Ahrefs (paid).

Rule: **one primary intent = one page.** Articles target informational intent and link to the commercial page; they never target the commercial keyword itself.

| Primary intent (FR) | Type | Page (only page that targets it) | Secondary / variants |
|---|---|---|---|
| agence génération de leads maroc | Commercial | /services/lead-generation/ | génération de leads qualifiés, lead generation maroc, prospects qualifiés |
| agence acquisition client maroc / casablanca | Commercial (brand-category) | / (home) | agence marketing digital maroc orientée résultats |
| agence meta ads maroc | Commercial | /services/meta-ads/ | publicité facebook maroc, publicité instagram maroc, agence facebook ads casablanca |
| funnel de conversion | Commercial/info | /services/conversion-funnels/ | landing page qui convertit, tunnel de vente |
| qualification de leads | Commercial/info | /services/lead-qualification/ | scoring leads, filtrer prospects |
| automatisation whatsapp entreprise maroc | Commercial | /services/crm-whatsapp-automation/ | crm whatsapp, relance whatsapp automatique, crm pour centre de formation |
| améliorer taux de conversion leads | Commercial/info | /services/sales-conversion/ | transformer leads en clients, script appel de vente |
| marketing centre de formation maroc | Commercial | /industries/training-centers/ | acquisition clients centre de formation, publicité centre de formation |
| marketing centre de langues / école de langues | Commercial | /industries/language-centers/ | inscriptions école de langues, publicité centre de langues |
| génération de prospects coach | Commercial | /industries/coaches-consultants/ | trouver des clients coach maroc, clients consultant |
| vendre une formation en ligne maroc | Commercial | /industries/course-creators/ | acquisition élèves formation en ligne |
| différence lead et lead qualifié | Informational | /insights/lead-vs-lead-qualifie/ | c'est quoi un lead qualifié |
| relancer prospects centre de formation | Informational | /insights/relance-prospects-centre-de-formation/ | relance prospect whatsapp, suivi prospects |
| budget meta ads maroc | Informational | /insights/budget-meta-ads-maroc/ | combien coûte la publicité facebook au maroc |

Not targeted on purpose: "agence marketing digital maroc" as a generic head term (very competitive, attracts social-media-management buyers Aura does not want). The home page mentions it naturally only.

## Future languages
- Darija / Arabic (`/ar/`) and English (`/en/`) once real, reviewed translations exist. Add the locale to `lib/site.ts → locales`, create the routes, and add `alternates.languages` (hreflang) in `lib/seo.ts`. Never publish machine-translated empty pages.
